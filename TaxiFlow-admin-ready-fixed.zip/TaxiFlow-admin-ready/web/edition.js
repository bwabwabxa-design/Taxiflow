window.TAXIFLOW_EDITION=location.pathname.replace(/\/$/,'')==='/chauffeur'?'driver':'dispatch';
