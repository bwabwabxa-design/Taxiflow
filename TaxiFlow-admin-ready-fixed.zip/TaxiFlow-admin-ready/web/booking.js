'use strict';
(()=>{const $=s=>document.querySelector(s),points={},timers={},versions={},controllers={};let tracking=null,sending=false;
async function api(path,method='GET',body,options={}){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),75000);
  try{
    const r=await fetch('/api/v1/public'+path,{method,headers:{'Content-Type':'application/json',...(options.headers||{})},...(body?{body:JSON.stringify(body)}:{}),signal:options.signal||controller.signal});
    let d;try{d=await r.json();}catch{throw Error('La centrale redémarre peut-être. Patientez quelques instants, puis réessayez.');}
    if(!r.ok){const err=Error(typeof d.detail==='string'?d.detail:'Vérifiez les informations saisies.');err.status=r.status;throw err;}return d;
  }catch(e){if(e.name==='AbortError')throw e;if(e instanceof TypeError)throw Error('Connexion à la centrale interrompue. Réessayez : votre demande ne sera pas créée deux fois.');throw e;}finally{clearTimeout(timer);}
}
function message(t){$('#message').textContent=t;}
function choose(key,p){versions[key]=(versions[key]||0)+1;controllers[key]?.abort();points[key]=p;$('#'+key).value=p.label;$('#'+key+'-results').textContent='✓ Adresse sélectionnée';}
async function suggest(key,query,version){
 const el=$('#'+key+'-results');controllers[key]?.abort();const ctrl=controllers[key]=new AbortController();el.textContent='Recherche d’adresses…';
 const timeout=setTimeout(()=>ctrl.abort(),20000);
 try{const results=await api('/geocode?q='+encodeURIComponent(query),'GET',null,{signal:ctrl.signal});if(version!==versions[key])return;el.replaceChildren();
 if(!results.length){el.textContent='Aucune adresse trouvée. Ajoutez la ville ou le code postal.';return;}
 results.slice(0,6).forEach(p=>{const btn=document.createElement('button');btn.type='button';btn.className='btn secondary';btn.textContent=p.label;btn.onclick=()=>choose(key,p);el.append(btn);});
 }catch(err){if(version===versions[key])el.textContent=err.name==='AbortError'?'Recherche trop longue. Modifiez votre adresse pour réessayer.':err.message;}finally{clearTimeout(timeout);}
}
document.addEventListener('input',e=>{const key=e.target.id;if(!['pickup','destination'].includes(key))return;delete points[key];clearTimeout(timers[key]);controllers[key]?.abort();const version=versions[key]=(versions[key]||0)+1;const query=e.target.value.trim();$('#'+key+'-results').textContent='';if(query.length>=3)timers[key]=setTimeout(()=>suggest(key,query,version),450);});
$('#locate').onclick=()=>{if(!navigator.geolocation){message('La géolocalisation n’est pas disponible. Saisissez votre adresse.');return;}
 $('#locate').disabled=true;navigator.geolocation.getCurrentPosition(p=>{if(p.coords.accuracy>500)message('Position trop imprécise. Saisissez une adresse pour faciliter la prise en charge.');else{choose('pickup',{label:'Ma position GPS — précisez le point de rendez-vous en note',lat:p.coords.latitude,lon:p.coords.longitude});message('Position sélectionnée. Ajoutez un point de rendez-vous précis dans les instructions.');}$('#locate').disabled=false;},()=>{message('Position indisponible ou autorisation refusée. Saisissez votre adresse.');$('#locate').disabled=false;},{enableHighAccuracy:true,timeout:15000,maximumAge:30000});};
$('#booking').addEventListener('submit',async e=>{e.preventDefault();if(sending)return;sending=true;$('#send').disabled=true;$('#send').textContent='Transmission à la centrale…';
 try{if(!points.pickup||!points.destination)throw Error('Sélectionnez le départ et la destination parmi les propositions.');const f=Object.fromEntries(new FormData(e.target));if(f.scheduled_at&&new Date(f.scheduled_at)<=new Date())throw Error('Choisissez un départ dans le futur ou laissez la date vide.');
 const payload={consent:true,trip:{...f,passengers:Number(f.passengers),pickup:points.pickup,destination:points.destination,scheduled_at:f.scheduled_at?new Date(f.scheduled_at).toISOString():null}};
 // Keep the same payload/key after an uncertain network response; never duplicate a booking.
 let pending=JSON.parse(sessionStorage.getItem('tf-pending-booking')||'null');if(pending&&pending.payload!==JSON.stringify(payload))throw Error('Une précédente demande reste à vérifier. Rechargez cette page pour récupérer son résultat avant de modifier la réservation.');
 if(!pending){pending={payload:JSON.stringify(payload),key:crypto.randomUUID()};sessionStorage.setItem('tf-pending-booking',JSON.stringify(pending));}
 await sendPending(pending);
 }catch(err){message(err.name==='AbortError'?'La centrale met du temps à répondre. Réessayez avec les mêmes informations.':err.message);}finally{sending=false;$('#send').disabled=false;$('#send').textContent='Demander ma réservation';}
});
async function sendPending(pending){let result;try{result=await api('/bookings','POST',JSON.parse(pending.payload),{headers:{'Idempotency-Key':pending.key}});}catch(e){if([400,422].includes(e.status)){sessionStorage.removeItem('tf-pending-booking');$('#booking').hidden=false;}throw e;}tracking={reference:result.reference,token:result.token};sessionStorage.setItem('taxiflow-client-tracking',JSON.stringify(tracking));sessionStorage.removeItem('tf-pending-booking');location.hash=new URLSearchParams(tracking).toString();$('#booking').hidden=true;message('Demande transmise. Estimation indicative : '+(result.estimate_cents/100).toFixed(2)+' €'+(result.approximate?' (itinéraire approximatif)':'')+'. Conservez ce lien privé pour suivre votre demande.');await refresh();}
async function refresh(){if(!tracking)return;try{const r=await api('/track','POST',tracking),el=$('#tracking');el.hidden=false;el.replaceChildren();const h=document.createElement('h2');h.textContent={requested:'Demande en attente',accepted:'Demande acceptée',declined:'Demande refusée',pending:'Recherche de chauffeur',scheduled:'Course réservée',assigned:'Chauffeur attribué',en_route:r.arrived?'Votre taxi est arrivé':'Votre taxi est en route',on_board:'Trajet en cours',completed:'Trajet terminé',cancelled:'Course annulée'}[r.status]||r.status;el.append(h);if(r.driver){const p=document.createElement('p');p.textContent=r.driver.callsign+' · '+r.driver.vehicle+' · '+r.driver.plate;el.append(p);}if(r.location){const a=document.createElement('a');a.textContent='Voir la dernière position du taxi';a.href='https://maps.apple.com/?ll='+r.location.lat+','+r.location.lon;a.rel='noreferrer';el.append(a);}const note=document.createElement('p');note.textContent='Mise à jour : '+new Date().toLocaleTimeString('fr-FR')+' · Paiement : '+(r.payment_status==='paid'?'enregistré':'à régler à bord');el.append(note);const newBooking=document.createElement('a');newBooking.href='/reservation?nouvelle=1';newBooking.textContent='Faire une autre réservation';el.append(newBooking);}catch(err){message(err.name==='AbortError'?'Actualisation trop longue, nouvelle tentative automatique.':err.message);}}
const q=new URLSearchParams(location.hash.slice(1));if(q.get('reference')&&q.get('token'))tracking={reference:q.get('reference'),token:q.get('token')};
if(new URLSearchParams(location.search).has('nouvelle'))sessionStorage.removeItem('taxiflow-client-tracking');else if(!tracking){try{tracking=JSON.parse(sessionStorage.getItem('taxiflow-client-tracking')||'null');}catch{}}
if(tracking){$('#booking').hidden=true;refresh();}else{const pending=sessionStorage.getItem('tf-pending-booking');if(pending){$('#booking').hidden=true;message('Vérification de votre dernière demande…');sendPending(JSON.parse(pending)).catch(e=>{message(e.message+' Rechargez pour réessayer.');});}}
setInterval(()=>{if(!document.hidden)refresh();},10000);
})();
