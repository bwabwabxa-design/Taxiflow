# Corrections TaxiFlow

## Vérifications
16 tests API réussis sur copie locale isolée : comptes et permissions, cycle de course, affectation concurrente, paiement, inscription chauffeur et validation.

## Modifications
- L’inscription répond avant les tentatives d’envoi e-mail ; leur échec ne bloque plus la création du compte.
- Validation des noms, véhicules et adresses e-mail.
- Les erreurs e-mail ne journalisent plus les adresses des chauffeurs.
- Le contrôle de santé renvoie la version réelle de l’API.
- Les sources web acceptent un délai plus long pendant la connexion au serveur endormi.

## Mise en ligne
Remplacer TaxiFlow-admin-ready-fixed.zip à la racine du dépôt existant. La structure TaxiFlow-admin-ready/ est conservée : les commandes Render actuelles restent valides. Déploiement automatique actuellement désactivé : lancer Manual Deploy / Deploy latest commit.

## Limites restant à traiter
La base SQLite sous /tmp sur Render Free n’est pas persistante. Les e-mails sont différés mais leur livraison n’est pas garantie ; SMTP reste soumis aux restrictions du fournisseur. Les IPA déjà installées ne sont pas modifiées par ce ZIP. Aucun test natif sur iPhone ni réservation réelle de bout en bout n’a été réalisé pour cette correction.
