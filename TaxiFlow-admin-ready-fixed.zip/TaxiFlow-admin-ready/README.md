# TaxiFlow 2.0

Voir [DEPLOIEMENT-2.0.md](DEPLOIEMENT-2.0.md) pour les liens, la configuration Google/Apple, Render et les deux IPA LiveContainer.

Sources serveur : api/ ; interfaces : web/ ; applications iOS : mobile/.
