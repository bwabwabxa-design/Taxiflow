"""OAuth authorization code + verified OIDC. Browser pairing works without app URL schemes.
Existing accounts must explicitly associate a provider while signed in; email matching
never grants access. Provider credentials exist only in server environment variables.
"""
import base64, hashlib, hmac, html, json, os, secrets, time, logging
from contextlib import closing
from urllib.parse import urlencode, parse_qs
from typing import Literal
import httpx, jwt
from fastapi import HTTPException, Request
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
from . import main as m

PROVIDERS = {
 'google': {'authorize':'https://accounts.google.com/o/oauth2/v2/auth','token':'https://oauth2.googleapis.com/token','keys':'https://www.googleapis.com/oauth2/v3/certs','issuer':'https://accounts.google.com'},
 'apple': {'authorize':'https://appleid.apple.com/auth/authorize','token':'https://appleid.apple.com/auth/token','keys':'https://appleid.apple.com/auth/keys','issuer':'https://appleid.apple.com'},
}

def digest(value): return hashlib.sha256(value.encode()).hexdigest()
def base(): return os.getenv('PUBLIC_BASE_URL','https://taxiflow-54s9.onrender.com').rstrip('/')
def client_id(provider): return os.getenv(provider.upper()+'_CLIENT_ID','')
def enabled(provider):
    if not base().startswith('https://') or not client_id(provider): return False
    if provider=='google': return bool(os.getenv('GOOGLE_CLIENT_SECRET'))
    return bool(os.getenv('APPLE_TEAM_ID') and os.getenv('APPLE_KEY_ID') and os.getenv('APPLE_PRIVATE_KEY'))
def init_db():
    with closing(m.connection()) as db:
        db.executescript('''CREATE TABLE IF NOT EXISTS oauth_identities(provider TEXT, subject TEXT, user_id TEXT REFERENCES users(id) ON DELETE CASCADE, PRIMARY KEY(provider,subject), UNIQUE(provider,user_id));
        CREATE TABLE IF NOT EXISTS oauth_flows(id TEXT PRIMARY KEY, data TEXT NOT NULL, expires REAL NOT NULL, ip TEXT NOT NULL);''')
def get_flow(db, state):
    row=db.execute('SELECT data FROM oauth_flows WHERE id=? AND expires>?',(digest(state),time.time())).fetchone()
    if not row: raise HTTPException(410,'Connexion expirée. Recommence depuis TaxiFlow.')
    return json.loads(row[0])
def save_flow(db,state,data): db.execute('UPDATE oauth_flows SET data=? WHERE id=?',(json.dumps(data),digest(state)))

def page(text, form=''):
    return HTMLResponse('<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TaxiFlow · Connexion</title><style>body{font:18px system-ui;background:#f5f6f8;color:#142136;max-width:480px;margin:12vh auto;padding:24px}section{background:white;padding:28px;border-radius:24px}input,button{box-sizing:border-box;width:100%;padding:16px;border-radius:12px;font:inherit;margin:10px 0;border:1px solid #ddd}button{background:#ffce38;color:#142136;font-weight:700}p{line-height:1.55}</style><section><h1>TaxiFlow</h1><p>'+html.escape(text)+'</p>'+form+'</section></html>',headers={'Cache-Control':'no-store','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'"})

class Start(BaseModel):
    provider: Literal['google','apple']
    mode: Literal['login','link']='login'
class Poll(BaseModel):
    state: str=Field(min_length=20,max_length=100)
    secret: str=Field(min_length=20,max_length=100)

async def verify_identity(provider, code, flow):
    config=PROVIDERS[provider]; secret=os.getenv('GOOGLE_CLIENT_SECRET','')
    if provider=='apple':
        now=int(time.time())
        secret=jwt.encode({'iss':os.environ['APPLE_TEAM_ID'],'iat':now,'exp':now+300,'aud':'https://appleid.apple.com','sub':client_id(provider)},os.environ['APPLE_PRIVATE_KEY'].replace('\\n','\n'),algorithm='ES256',headers={'kid':os.environ['APPLE_KEY_ID']})
    payload={'grant_type':'authorization_code','code':code,'client_id':client_id(provider),'client_secret':secret,'redirect_uri':base()+'/api/v1/auth/oauth/'+provider+'/callback'}
    if provider=='google': payload['code_verifier']=flow['verifier']
    async with httpx.AsyncClient(timeout=15) as client:
        response=await client.post(config['token'],data=payload);response.raise_for_status()
        encoded=response.json()['id_token']
        keys=await client.get(config['keys']);keys.raise_for_status()
    header=jwt.get_unverified_header(encoded)
    if header.get('alg')!='RS256': raise ValueError('Invalid algorithm')
    jwk=next(k for k in keys.json()['keys'] if k.get('kid')==header.get('kid') and k.get('kty')=='RSA')
    claims=jwt.decode(encoded,jwt.PyJWK.from_dict(jwk).key,algorithms=['RS256'],audience=client_id(provider),issuer=config['issuer'],options={'require':['exp','iat','sub','iss','aud','nonce']},leeway=20)
    if not isinstance(claims['sub'],str) or not claims['sub'] or not hmac.compare_digest(claims['nonce'],flow['nonce']): raise ValueError('Invalid identity')
    if claims.get('azp',client_id(provider))!=client_id(provider):raise ValueError('Invalid authorized party')
    return claims['sub']

class SafeOAuthLog(logging.Filter):
    def filter(self, record):
        if isinstance(record.args, tuple) and len(record.args)==5 and '/auth/oauth/' in str(record.args[2]):
            args=list(record.args);args[2]=str(args[2]).split('?')[0];record.args=tuple(args)
        return True
logging.getLogger('uvicorn.access').addFilter(SafeOAuthLog())

def install(app):
    @app.get('/api/v1/auth/providers')
    def providers(): return {p:{'enabled':enabled(p)} for p in PROVIDERS}

    @app.post('/api/v1/auth/oauth/start')
    def start(body: Start, request: Request):
        if not enabled(body.provider): raise HTTPException(503,'La connexion '+body.provider.title()+' attend sa configuration officielle sur le serveur. Utilise ton e-mail et ton mot de passe.')
        user=m.current_user(request) if body.mode=='link' else None
        state=secrets.token_urlsafe(32); poll=secrets.token_urlsafe(32); pairing=str(secrets.randbelow(1000000)).zfill(6)
        data={'provider':body.provider,'mode':body.mode,'link_user':user['id'] if user else None,'poll':digest(poll),'pairing':digest(pairing),'attempts':0,'nonce':secrets.token_urlsafe(32),'verifier':secrets.token_urlsafe(48),'status':'pending'}
        ip=request.client.host if request.client else 'unknown'
        with m.tx() as db:
            db.execute('DELETE FROM oauth_flows WHERE expires<?',(time.time(),))
            if db.execute('SELECT count(*) FROM oauth_flows WHERE ip=?',(ip,)).fetchone()[0]>=20: raise HTTPException(429,'Trop de tentatives. Réessaie dans dix minutes.')
            db.execute('INSERT INTO oauth_flows VALUES(?,?,?,?)',(digest(state),json.dumps(data),time.time()+600,ip))
        params={'client_id':client_id(body.provider),'redirect_uri':base()+'/api/v1/auth/oauth/'+body.provider+'/callback','response_type':'code','scope':'openid email profile' if body.provider=='google' else 'name email','state':state,'nonce':data['nonce']}
        if body.provider=='google': params.update(code_challenge=base64.urlsafe_b64encode(hashlib.sha256(data['verifier'].encode()).digest()).decode().rstrip('='),code_challenge_method='S256',prompt='select_account')
        else: params['response_mode']='form_post'
        return {'url':PROVIDERS[body.provider]['authorize']+'?'+urlencode(params),'state':state,'secret':poll,'pairing_code':pairing,'expires_in':600}

    @app.api_route('/api/v1/auth/oauth/{provider}/callback',methods=['GET','POST'],include_in_schema=False)
    async def callback(provider: str, request: Request):
        if provider not in PROVIDERS:raise HTTPException(404)
        if request.method=='POST':
            raw=await request.body()
            if len(raw)>32768:raise HTTPException(413)
            values={k:v[0] for k,v in parse_qs(raw.decode()).items()}
        else: values=dict(request.query_params)
        state=values.get('state','')
        with m.tx() as db:
            flow=get_flow(db,state)
            if flow['provider']!=provider or flow['status']!='pending':raise HTTPException(400,'Retour de connexion déjà utilisé ou incorrect.')
            flow['status']='verifying';save_flow(db,state,flow)
        try:
            if values.get('error') or not values.get('code'):raise ValueError('Authorization denied')
            subject=await verify_identity(provider,values['code'],flow)
            confirm=secrets.token_urlsafe(32)
            with m.tx() as db:
                flow=get_flow(db,state);flow.update(subject=subject,status='confirm',confirm=digest(confirm));save_flow(db,state,flow)
            form='<form method="post" action="/api/v1/auth/oauth/confirm"><input type="hidden" name="state" value="'+html.escape(state,quote=True)+'"><input type="hidden" name="confirm" value="'+confirm+'"><label>Code affiché dans TaxiFlow<input name="pairing" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="off" required></label><button>Autoriser mon appareil</button></form>'
            return page('Saisis le code à 6 chiffres affiché dans ton application TaxiFlow. Continue uniquement si tu viens de demander cette connexion sur ton propre appareil.',form)
        except (ValueError,KeyError,StopIteration,jwt.PyJWTError,httpx.HTTPError):
            with m.tx() as db:
                flow=get_flow(db,state);flow.update(status='error',error='Connexion refusée ou identité non vérifiable. Réessaie.');save_flow(db,state,flow)
            return page('Connexion non validée. Reviens dans TaxiFlow pour réessayer.')

    @app.post('/api/v1/auth/oauth/confirm',include_in_schema=False)
    async def confirm(request: Request):
        raw=await request.body()
        if len(raw)>4096:raise HTTPException(413)
        values={k:v[0] for k,v in parse_qs(raw.decode()).items()}; state=values.get('state','')
        with m.tx() as db:
            f=get_flow(db,state)
            if f['status']!='confirm' or not hmac.compare_digest(f.get('confirm',''),digest(values.get('confirm',''))):raise HTTPException(400,'Confirmation invalide.')
            if not hmac.compare_digest(f['pairing'],digest(values.get('pairing',''))):
                f['attempts']+=1
                if f['attempts']>=5:f.update(status='error',error='Trop de codes incorrects. Recommence la connexion.')
                save_flow(db,state,f)
                return page('Code incorrect. Reviens à la page précédente pour saisir le code de TaxiFlow.')
            identity=db.execute('SELECT user_id FROM oauth_identities WHERE provider=? AND subject=?',(f['provider'],f['subject'])).fetchone()
            if f['mode']=='link':
                other=db.execute('SELECT subject FROM oauth_identities WHERE provider=? AND user_id=?',(f['provider'],f['link_user'])).fetchone()
                if (identity and identity[0]!=f['link_user']) or (other and other[0]!=f['subject']):
                    f.update(status='error',error='Ce compte est déjà associé. Contacte la centrale.')
                elif not db.execute('SELECT id FROM users WHERE id=?',(f['link_user'],)).fetchone():f.update(status='error',error='Compte TaxiFlow introuvable.')
                else:
                    db.execute('INSERT OR IGNORE INTO oauth_identities VALUES(?,?,?)',(f['provider'],f['subject'],f['link_user']))
                    f.update(status='ready',user_id=f['link_user'])
            elif identity:f.update(status='ready',user_id=identity[0])
            else:f.update(status='error',error='Compte non associé. Connecte-toi avec ton e-mail, puis ouvre Réglages > Associer '+f['provider'].title()+'.')
            save_flow(db,state,f)
        return page('Validation terminée. Reviens dans ton application TaxiFlow : elle reprendra automatiquement la connexion.')

    @app.post('/api/v1/auth/oauth/poll')
    def poll(body: Poll):
        with m.tx() as db:
            f=get_flow(db,body.state)
            if not hmac.compare_digest(f['poll'],digest(body.secret)):raise HTTPException(404,'Connexion introuvable.')
            if f['status']=='error':return {'status':'error','detail':f['error']}
            if f['status']!='ready':return {'status':'pending'}
            db.execute('DELETE FROM oauth_flows WHERE id=?',(digest(body.state),))
            if f['mode']=='link':return {'status':'linked'}
            user=db.execute('SELECT id,email,name,role,driver_id FROM users WHERE id=?',(f['user_id'],)).fetchone()
            if not user:raise HTTPException(401,'Compte introuvable.')
            token=secrets.token_urlsafe(40)
            db.execute('INSERT INTO sessions VALUES(?,?,?)',(digest(token),user['id'],time.time()+43200))
            m.audit(db,dict(user),'auth.oauth',f['provider'])
            return {'status':'complete','token':token,'expires_in':43200,'user':dict(user)}
