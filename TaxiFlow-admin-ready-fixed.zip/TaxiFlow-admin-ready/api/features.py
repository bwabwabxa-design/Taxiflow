"""TaxiFlow 1.1: driver responses, public bookings, series and Stripe Checkout.
All external services are disabled until configured. No credentials in the app.
"""
import hashlib, hmac, json, os, time, secrets
from contextlib import closing
from datetime import datetime, timezone
from fastapi import Depends, HTTPException, Request
from pydantic import BaseModel, Field, field_validator
from typing import Literal
import httpx
from . import main as m


def install(app):
    @app.post('/api/v1/trips/{ident}/response')
    def respond(ident: str, body: DriverResponse, user=Depends(m.current_user)):
        with m.tx() as db:
            t=m.get(db,'trips',ident); m.version_check(t,body.version)
            if user['role']=='driver' and t.get('driver_id')!=user['driver_id']:
                raise HTTPException(403,'Cette course ne t’est pas attribuée.')
            if body.action in ('accept','refuse'):
                if t['status']!='assigned' or t.get('accepted_at'):raise HTTPException(409,'La proposition a déjà été traitée.')
                if body.action=='accept':t['accepted_at']=m.now()
                else:
                    d=m.get(db,'drivers',t['driver_id']);d['status']='available';m.put(db,'drivers',d)
                    t.setdefault('refusals',[]).append({'driver_id':t['driver_id'],'at':m.now()})
                    t.update(driver_id=None,status='pending')
            else:
                if t['status']!='en_route' or t.get('arrived_at'):raise HTTPException(409,'Arrivée déjà signalée ou course non démarrée.')
                t['arrived_at']=m.now()
            t.update(version=t['version']+1,updated_at=m.now());m.put(db,'trips',t)
            m.audit(db,user,'trip.'+body.action,ident)
            return t

    @app.post('/api/v1/series')
    async def series(body: Series, request: Request, user=Depends(m.dispatcher)):
        data=body.model_dump(mode='json');digest=hashlib.sha256(json.dumps(data,sort_keys=True).encode()).hexdigest()
        key=request.headers.get('Idempotency-Key','')[:128]
        if not key:raise HTTPException(422,'Une clé de création est requise.')
        route=await m.route_info(data['trip']['pickup'],data['trip']['destination'])
        with m.tx() as db:
            old=db.execute('SELECT data FROM series WHERE id=?',(user['id']+':'+key,)).fetchone()
            if old:
                old=json.loads(old[0])
                if old['hash']!=digest:raise HTTPException(409,'Clé déjà utilisée.')
                return old['result']
            settings=json.loads(db.execute('SELECT data FROM settings WHERE id=1').fetchone()[0])
            if data['trip'].get('customer_id'):m.get(db,'customers',data['trip']['customer_id'])
            sid=m.uid('series');ids=[]
            for date in sorted(set(data['dates'])):
                if m.stamp(date)<time.time() or m.stamp(date)>time.time()+366*86400:raise HTTPException(422,'Dates futures, dans la prochaine année, requises.')
                t={**data['trip'],**route,'id':m.uid('trp'),'series_id':sid,'scheduled_at':date,'driver_id':None,'status':'scheduled','version':1,'payment_status':'unpaid','created_at':m.now(),'updated_at':m.now(),'fare_cents':m.fare(settings,route,body.trip.category)}
                m.put(db,'trips',t);ids.append(t['id'])
            result={'id':sid,'trip_ids':ids,'count':len(ids)}
            db.execute('INSERT INTO series VALUES(?,?)',(user['id']+':'+key,json.dumps({'hash':digest,'result':result})))
            m.audit(db,user,'series.created',sid,str(len(ids)))
            return result

    @app.post('/api/v1/series/{ident}/cancel')
    def cancel_series(ident: str, user=Depends(m.dispatcher)):
        with m.tx() as db:
            n=0
            for t in m.rows(db,'trips'):
                if t.get('series_id')==ident and t['status'] in ('pending','scheduled'):
                    t.update(status='cancelled',version=t['version']+1,updated_at=m.now());m.put(db,'trips',t);n+=1
            m.audit(db,user,'series.cancelled',ident,str(n));return {'count':n}

    @app.get('/api/v1/services')
    def services(user=Depends(m.current_user)):
        return {'booking_enabled':os.getenv('PUBLIC_BOOKING_ENABLED')=='1','public_url':os.getenv('PUBLIC_BASE_URL','').rstrip('/')+'/booking.html',
                'stripe_enabled':bool(os.getenv('STRIPE_SECRET_KEY') and os.getenv('STRIPE_WEBHOOK_SECRET') and os.getenv('PUBLIC_BASE_URL')),
                'sms_enabled':bool(os.getenv('TWILIO_ACCOUNT_SID') and os.getenv('TWILIO_AUTH_TOKEN') and os.getenv('TWILIO_FROM'))}

    @app.get('/api/v1/public/geocode')
    async def public_geocode(q: str, request: Request):
        public_limit(request,40);return await m.geocode(q,user={})

    @app.post('/api/v1/public/bookings')
    async def booking(body: PublicBooking, request: Request):
        public_limit(request,6)
        # Store as a request, never allocate a driver or trust a customer-supplied price.
        if not body.consent:raise HTTPException(422,'Le consentement à la gestion de la demande est requis.')
        raw=body.trip.model_dump(mode='json');raw.update(customer_id=None,priority='normal')
        key=request.headers.get('Idempotency-Key','')
        if key and (len(key)<32 or len(key)>128):raise HTTPException(422,'Clé de réservation invalide.')
        token=key or secrets.token_urlsafe(32)
        ident='req_'+hashlib.sha256(token.encode()).hexdigest()[:40]
        payload_hash=hashlib.sha256(json.dumps(raw,sort_keys=True).encode()).hexdigest()
        def existing(db):
            row=db.execute('SELECT data FROM bookings WHERE id=?',(ident,)).fetchone()
            if row:
                old=json.loads(row[0])
                if old.get('request_hash')!=payload_hash:raise HTTPException(409,'Cette demande a déjà été envoyée avec des informations différentes. Consulte son suivi avant de recommencer.')
                return old
        def result(data):return {'reference':ident,'token':token,'estimate_cents':data['estimate_cents'],'approximate':data['route'].get('approximate',False),'status':data['status']}
        with closing(m.connection()) as db:
            old=existing(db)
            if old:return result(old)
        route=await m.route_info(raw['pickup'],raw['destination'])
        with m.tx() as db:
            old=existing(db)
            if old:return result(old)
            settings=json.loads(db.execute('SELECT data FROM settings WHERE id=1').fetchone()[0])
            data={'id':ident,'trip':raw,'created_at':m.now(),'status':'requested','tracking_hash':hashlib.sha256(token.encode()).hexdigest(),'request_hash':payload_hash,'route':route,'estimate_cents':m.fare(settings,route,body.trip.category)}
            m.put(db,'bookings',data)
        return result(data)

    @app.post('/api/v1/public/track')
    def track(body: Tracking, request: Request):
        public_limit(request,90)
        with closing(m.connection()) as db:
            b=m.get(db,'bookings',body.reference)
            if not hmac.compare_digest(b['tracking_hash'],hashlib.sha256(body.token.encode()).hexdigest()):raise HTTPException(404,'Demande introuvable.')
            result={'reference':b['id'],'status':b['status'],'estimate_cents':b['estimate_cents']}
            if b.get('trip_id'):
                t=m.get(db,'trips',b['trip_id']);result.update(status=t['status'],arrived=bool(t.get('arrived_at')),payment_status=t['payment_status'])
                if t.get('driver_id') and t['status'] in m.ACTIVE:
                    d=m.get(db,'drivers',t['driver_id']);result['driver']={k:d.get(k) for k in ('callsign','vehicle','plate')}
                    # Position only during pickup and only if recent; no full fleet exposure.
                    if t['status'] in ('assigned','en_route') and m.fresh(d):result['location']={k:d[k] for k in ('lat','lon','location_updated_at')}
            return result

    @app.get('/api/v1/bookings')
    def bookings(user=Depends(m.dispatcher)):
        with closing(m.connection()) as db:return [{k:v for k,v in b.items() if k!='tracking_hash'} for b in m.rows(db,'bookings')]

    @app.post('/api/v1/bookings/{ident}/decision')
    def booking_decision(ident: str, body: Decision, user=Depends(m.dispatcher)):
        with m.tx() as db:
            b=m.get(db,'bookings',ident)
            if b['status']!='requested':return {k:v for k,v in b.items() if k!='tracking_hash'}
            if body.accept:
                data=b['trip'];settings=json.loads(db.execute('SELECT data FROM settings WHERE id=1').fetchone()[0])
                if data.get('scheduled_at') and m.stamp(data['scheduled_at'])<time.time():data['scheduled_at']=None
                t={**data,**b['route'],'id':m.uid('trp'),'driver_id':None,'status':'scheduled' if data.get('scheduled_at') else 'pending','version':1,'created_at':m.now(),'updated_at':m.now(),'payment_status':'unpaid','fare_cents':m.fare(settings,b['route'],data['category'])}
                m.put(db,'trips',t);b.update(status='accepted',trip_id=t['id'])
            else:b['status']='declined'
            m.put(db,'bookings',b);m.audit(db,user,'booking.'+b['status'],ident)
            return {k:v for k,v in b.items() if k!='tracking_hash'}

    @app.post('/api/v1/trips/{ident}/checkout')
    async def checkout(ident: str, body: Checkout, user=Depends(m.current_user)):
        secret=os.getenv('STRIPE_SECRET_KEY');base=os.getenv('PUBLIC_BASE_URL','').rstrip('/')
        if not secret or not base.startswith('https://') or not os.getenv('STRIPE_WEBHOOK_SECRET'):raise HTTPException(503,'Configurer Stripe et PUBLIC_BASE_URL HTTPS sur le serveur.')
        with m.tx() as db:
            t=m.get(db,'trips',ident)
            if user['role']=='driver' and t.get('driver_id')!=user['driver_id']:raise HTTPException(403,'Accès refusé.')
            if t.get('checkout_url') and t.get('checkout_expires',0)>time.time() and t['payment_status']!='paid':return {'url':t['checkout_url']}
            m.version_check(t,body.version)
            if t['status']!='completed' or t['payment_status']=='paid':raise HTTPException(409,'Une course terminée et non réglée est requise.')
            # Reserve a stable attempt and amount before calling Stripe, including after network failures.
            if not t.get('checkout_attempt') or t.get('checkout_expires',0)<time.time():
                t.update(checkout_attempt=secrets.token_hex(12),checkout_amount=body.amount_cents,checkout_expires=int(time.time())+3600)
            m.put(db,'trips',t)
        data={'mode':'payment','payment_method_types[0]':'card','line_items[0][price_data][currency]':'eur','line_items[0][price_data][unit_amount]':str(t['checkout_amount']),'line_items[0][price_data][product_data][name]':'Course TaxiFlow '+ident,'line_items[0][quantity]':'1','metadata[trip_id]':ident,'metadata[attempt]':t['checkout_attempt'],'expires_at':str(t['checkout_expires']),'success_url':base+'/payment.html?result=success','cancel_url':base+'/payment.html?result=cancel'}
        try:
            async with httpx.AsyncClient(timeout=15) as client:
                r=await client.post('https://api.stripe.com/v1/checkout/sessions',data=data,auth=(secret,''),headers={'Idempotency-Key':t['checkout_attempt']});r.raise_for_status();session=r.json()
        except (httpx.HTTPError,ValueError):raise HTTPException(502,'Stripe indisponible. Réessaie : la demande reste protégée contre les doublons.')
        with m.tx() as db:
            latest=m.get(db,'trips',ident);latest.update(checkout_url=session['url'],checkout_session=session['id']);m.put(db,'trips',latest)
        return {'url':session['url']}

    @app.post('/api/v1/stripe/webhook')
    async def stripe_webhook(request: Request):
        secret=os.getenv('STRIPE_WEBHOOK_SECRET','');raw=await request.body()
        if len(raw)>262144:raise HTTPException(413,'Payload trop volumineux.')
        header=request.headers.get('Stripe-Signature','');parts=[x.split('=',1) for x in header.split(',') if '=' in x]
        stamps=[v for k,v in parts if k=='t'];signatures=[v for k,v in parts if k=='v1']
        try:ts=int(stamps[0])
        except (ValueError,IndexError):raise HTTPException(400,'Signature absente.')
        digest=hmac.new(secret.encode(),str(ts).encode()+b'.'+raw,hashlib.sha256).hexdigest()
        if not secret or abs(time.time()-ts)>300 or not any(hmac.compare_digest(digest,s) for s in signatures):raise HTTPException(400,'Signature invalide.')
        event=json.loads(raw)
        if event.get('type')=='checkout.session.completed':
            session=event['data']['object'];meta=session.get('metadata',{})
            with m.tx() as db:
                if db.execute('SELECT 1 FROM stripe_events WHERE id=?',(event['id'],)).fetchone():return {'ok':True}
                t=m.get(db,'trips',meta.get('trip_id',''))
                if session.get('payment_status')!='paid' or session.get('currency')!='eur' or meta.get('attempt')!=t.get('checkout_attempt') or session.get('amount_total')!=t.get('checkout_amount'):raise HTTPException(400,'Paiement incohérent.')
                if t['payment_status']!='paid':
                    t.update(payment_status='paid',payment_method='card',paid_cents=session['amount_total'],paid_at=m.now(),version=t['version']+1,updated_at=m.now(),payment_source='stripe');m.put(db,'trips',t)
                    m.audit(db,{'id':'stripe'},'payment.confirmed',t['id'])
                db.execute('INSERT INTO stripe_events VALUES(?)',(event['id'],))
        return {'ok':True}

    @app.post('/api/v1/trips/{ident}/sms')
    async def sms(ident: str, body: SMS, user=Depends(m.current_user)):
        sid=os.getenv('TWILIO_ACCOUNT_SID');secret=os.getenv('TWILIO_AUTH_TOKEN');sender=os.getenv('TWILIO_FROM')
        if not all((sid,secret,sender)):raise HTTPException(503,'SMS non configurés sur le serveur.')
        with m.tx() as db:
            t=m.get(db,'trips',ident)
            if user['role']=='driver' and (t.get('driver_id')!=user['driver_id'] or body.recipient!='client'):raise HTTPException(403,'Accès refusé.')
            to=t['phone'] if body.recipient=='client' else m.get(db,'drivers',t.get('driver_id',''))['phone']
            import re
            if not re.fullmatch(r'\+[1-9][0-9]{7,14}',to):raise HTTPException(422,'Téléphone au format international requis, par exemple +336…')
            if body.recipient=='client' and not t.get('arrived_at'):raise HTTPException(409,'Signale d’abord ton arrivée.')
            text='Votre taxi est arrivé au point de rendez-vous.' if body.recipient=='client' else 'Nouvelle course TaxiFlow. Ouvrez votre espace chauffeur.'
            key=ident+':'+body.recipient
            if db.execute('SELECT 1 FROM sms_sent WHERE id=?',(key,)).fetchone():raise HTTPException(409,'Envoi déjà demandé. Vérifie le suivi Twilio avant tout nouvel essai.')
            db.execute('INSERT INTO sms_sent VALUES(?)',(key,))
        try:
            async with httpx.AsyncClient(timeout=12) as client:
                r=await client.post(f'https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json',auth=(sid,secret),data={'To':to,'From':sender,'Body':text});r.raise_for_status()
        except httpx.HTTPError:raise HTTPException(502,'Envoi non confirmé. Vérifie Twilio ; pas de réessai automatique pour éviter un doublon.')
        return {'status':'accepted_by_provider'}

class DriverResponse(BaseModel):
    action: Literal['accept','refuse','arrive']
    version: int = Field(ge=1)
class Series(BaseModel):
    trip: m.TripInput
    dates: list[datetime] = Field(min_length=1,max_length=60)
    @field_validator('dates')
    @classmethod
    def aware_dates(cls, dates):
        if any(d.tzinfo is None for d in dates):raise ValueError('Chaque date doit inclure un fuseau horaire.')
        return dates
class PublicBooking(BaseModel):
    trip: m.TripInput
    consent: bool
class Tracking(BaseModel):
    reference: str = Field(max_length=60)
    token: str = Field(min_length=20,max_length=100)
class Decision(BaseModel):
    accept: bool
class Checkout(BaseModel):
    amount_cents: int = Field(ge=50,le=1000000)
    version: int = Field(ge=1)
class SMS(BaseModel):
    recipient: Literal['client','driver']

public_attempts={}
def public_limit(request,limit):
    if os.getenv('PUBLIC_BOOKING_ENABLED')!='1':raise HTTPException(503,'Les réservations publiques ne sont pas encore ouvertes.')
    key=(request.client.host if request.client else '',request.url.path);minute=int(time.time()/60)
    # Bounded process-local limiter; edge rate limiting is also recommended for production.
    if len(public_attempts)>10000:public_attempts.clear()
    when,count=public_attempts.get(key,(minute,0));count=count+1 if when==minute else 1;public_attempts[key]=(minute,count)
    if count>limit:raise HTTPException(429,'Trop de demandes. Réessaie dans une minute.')
