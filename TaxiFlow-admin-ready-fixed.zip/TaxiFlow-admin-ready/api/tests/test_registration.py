from fastapi import BackgroundTasks
from starlette.requests import Request
from api import main as m
import pytest

def test_registration_queues_mail_and_preserves_account(tmp_path, monkeypatch):
    monkeypatch.setattr(m, 'DB_PATH', str(tmp_path/'signup.sqlite3'))
    m.init_db();m.registration_attempts.clear()
    def mail(*args):
        raise AssertionError('Mail must not run before the response')
    monkeypatch.setattr(m,'send_driver_registration_emails',mail)
    body=m.DriverRegistration(name='Test chauffeur',email='TEST@example.invalid',password='test-password-123',vehicle='Taxi test')
    tasks=BackgroundTasks()
    req=Request({'type':'http','client':('test',123),'headers':[]})
    result=m.register_driver(body,req,tasks)
    assert result['user']['role']=='driver'
    assert result['email_status']=='pending'
    assert len(tasks.tasks)==1
    with m.tx() as db:
        assert db.execute('SELECT count(*) FROM users').fetchone()[0]==1
        assert db.execute('SELECT count(*) FROM drivers').fetchone()[0]==1
    with pytest.raises(m.HTTPException) as e:m.register_driver(body,req,BackgroundTasks())
    assert e.value.status_code==409

@pytest.mark.parametrize('changes',[{'email':'bad'},{'name':'  '},{'vehicle':'  '}])
def test_signup_rejects_invalid_fields(changes):
    data=dict(name='Test chauffeur',email='test@example.invalid',password='test-password-123',vehicle='Taxi test')
    data.update(changes)
    with pytest.raises(ValueError):m.DriverRegistration(**data)
