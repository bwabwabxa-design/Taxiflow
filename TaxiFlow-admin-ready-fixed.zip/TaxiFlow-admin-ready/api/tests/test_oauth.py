import json, re, time
from urllib.parse import urlparse, parse_qs
import pytest, jwt, httpx
from cryptography.hazmat.primitives.asymmetric import rsa
from test_api import api,trip
from api import main as m, oauth as o, features

@pytest.fixture
def configured(monkeypatch):
    monkeypatch.setenv('GOOGLE_CLIENT_ID','test-client')
    monkeypatch.setenv('GOOGLE_CLIENT_SECRET','test-secret')
    monkeypatch.setenv('PUBLIC_BASE_URL','https://taxiflow.test')


def start(c,h=None):
    r=c.post('/api/v1/auth/oauth/start',headers=h or {},json={'provider':'google','mode':'link' if h else 'login'})
    assert r.status_code==200,r.text
    return r.json()

def finish(c,f,monkeypatch,subject='external-123'):
    async def verify(provider,code,flow):return subject
    monkeypatch.setattr(o,'verify_identity',verify)
    r=c.get('/api/v1/auth/oauth/google/callback',params={'state':f['state'],'code':'code'})
    assert r.status_code==200,r.text
    confirm=re.search('name="confirm" value="([^"]+)"',r.text).group(1)
    return {'state':f['state'],'confirm':confirm,'pairing':f['pairing_code']}

def poll(c,f,**kw):return c.post('/api/v1/auth/oauth/poll',json={'state':f['state'],'secret':f['secret'],**kw})

def test_unconfigured_fail_closed(api,monkeypatch):
    c,h=api;monkeypatch.delenv('GOOGLE_CLIENT_ID',raising=False)
    assert c.get('/api/v1/auth/providers').json()['google']['enabled'] is False
    assert c.post('/api/v1/auth/oauth/start',json={'provider':'google'}).status_code==503

def test_link_login_pairing_role_and_replay(api,configured,monkeypatch):
    c,h=api
    assert c.post('/api/v1/auth/oauth/start',json={'provider':'google','mode':'link'}).status_code==401
    f=start(c,h);params=parse_qs(urlparse(f['url']).query);assert params['code_challenge_method']==['S256']
    assert 'test-secret' not in f['url']
    assert poll(c,f,secret='x'*32).status_code==404
    data=finish(c,f,monkeypatch)
    assert poll(c,f).json()['status']=='pending'
    assert c.post('/api/v1/auth/oauth/confirm',data={**data,'pairing':'WRONG'}).status_code==200
    assert poll(c,f).json()['status']=='pending'
    assert c.post('/api/v1/auth/oauth/confirm',data=data).status_code==200
    assert poll(c,f).json()=={'status':'linked'}
    assert poll(c,f).status_code==410
    f=start(c);data=finish(c,f,monkeypatch);c.post('/api/v1/auth/oauth/confirm',data=data)
    result=poll(c,f).json();assert result['status']=='complete'
    assert result['user']['role']=='admin'
    state=c.get('/api/v1/state',headers={'Authorization':'Bearer '+result['token']});assert state.status_code==200
    assert poll(c,f).status_code==410

def test_unknown_identity_never_creates_admin(api,configured,monkeypatch):
    c,h=api;f=start(c);data=finish(c,f,monkeypatch)
    c.post('/api/v1/auth/oauth/confirm',data=data)
    assert poll(c,f).json()['status']=='error'
    with m.connection() as db:assert db.execute('SELECT count(*) FROM users').fetchone()[0]==1

def test_state_expiry_and_callback_replay(api,configured,monkeypatch):
    c,h=api;f=start(c)
    assert c.get('/api/v1/auth/oauth/google/callback',params={'state':'wrong'}).status_code==410
    finish(c,f,monkeypatch)
    assert c.get('/api/v1/auth/oauth/google/callback',params={'state':f['state'],'code':'reuse'}).status_code==400
    with m.tx() as db:db.execute('UPDATE oauth_flows SET expires=0')
    assert poll(c,f).status_code==410

def test_public_idempotency_and_tracking(api,monkeypatch):
    c,h=api;monkeypatch.setenv('PUBLIC_BOOKING_ENABLED','1');features.PUBLIC_HITS.clear() if hasattr(features,'PUBLIC_HITS') else None
    t=trip(c,h);payload={'trip':t,'consent':True};headers={'Idempotency-Key':'test-booking-secret-'+'a'*30}
    a=c.post('/api/v1/public/bookings',json=payload,headers=headers);assert a.status_code==200,a.text
    b=c.post('/api/v1/public/bookings',json=payload,headers=headers);assert a.json()==b.json()
    assert c.post('/api/v1/public/track',json={k:a.json()[k] for k in ('reference','token')}).status_code==200
    payload['trip']['passenger']='Changed';assert c.post('/api/v1/public/bookings',json=payload,headers=headers).status_code==409
    with m.connection() as db:assert db.execute('SELECT count(*) FROM bookings').fetchone()[0]==1

@pytest.mark.parametrize('invalid',['nonce','aud','iss','exp','signature',None])
def test_oidc_crypto_validation(configured,monkeypatch,invalid):
    import asyncio
    key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
    claims={'iss':'https://accounts.google.com','aud':'test-client','iat':int(time.time()),'exp':int(time.time())+300,'sub':'person123','nonce':'expected'}
    if invalid in ('nonce','aud','iss'):claims[invalid]='wrong'
    if invalid=='exp':claims['exp']=int(time.time())-100
    signing_key=rsa.generate_private_key(public_exponent=65537,key_size=2048) if invalid=='signature' else key
    token=jwt.encode(claims,signing_key,algorithm='RS256',headers={'kid':'k1'})
    jwk=json.loads(jwt.algorithms.RSAAlgorithm.to_jwk(key.public_key()));jwk['kid']='k1'
    class Client:
        def __init__(self,**kw):pass
        async def __aenter__(self):return self
        async def __aexit__(self,*args):pass
        async def post(self,url,**kw):return httpx.Response(200,json={'id_token':token},request=httpx.Request('POST',url))
        async def get(self,url):return httpx.Response(200,json={'keys':[jwk]},request=httpx.Request('GET',url))
    monkeypatch.setattr(o.httpx,'AsyncClient',Client)
    call=o.verify_identity('google','code',{'nonce':'expected','verifier':'verifier'})
    if invalid:
        with pytest.raises((jwt.PyJWTError,ValueError)):asyncio.run(call)
    else:assert asyncio.run(call)=='person123'
