#!/usr/bin/env python3
"""Build an ARM64 iOS app. Linux: Zig 0.13.0 (Clang) + LLVM LLD 18; macOS: Xcode's public SDK.
The output has no provisioning profile and must be signed before installation.
"""
import argparse
import json
import os
from pathlib import Path
import platform
import plistlib
import shutil
import subprocess
import zipfile
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent.parent


def write_stub(path, install, classes=(), symbols=()):
    path.parent.mkdir(parents=True, exist_ok=True)
    exports = list(symbols)
    for cls in classes:
        exports += ['_OBJC_CLASS_$_' + cls, '_OBJC_METACLASS_$_' + cls]
    path.write_text('--- !tapi-tbd\ntbd-version: 4\ntargets: [ arm64-ios ]\ninstall-name: '
                    + json.dumps(install) + '\ncurrent-version: 1\nexports:\n  - targets: [ arm64-ios ]\n    symbols: '
                    + json.dumps(exports) + '\n...\n')


def icons(app, driver=False):
    from PIL import Image, ImageDraw
    for name, size in [('AppIcon60x60@2x.png',120),('AppIcon60x60@3x.png',180),
                        ('AppIcon76x76.png',76),('AppIcon76x76@2x.png',152),('AppIcon83.5x83.5@2x.png',167),('AppIcon1024.png',1024)]:
        image = Image.new('RGB',(1024,1024),'#12564b' if driver else '#142136')
        draw = ImageDraw.Draw(image)
        scale=lambda pts:[(x*8,y*8) for x,y in pts]
        draw.polygon(scale([(29,89),(58,26),(77,26),(58,70),(101,70),(80,102),(60,102),(70,89)]),fill='#ffce38')
        draw.polygon(scale([(85,26),(99,40),(85,54),(72,54),(86,40),(72,26)]),fill='white')
        image.resize((size,size),Image.Resampling.LANCZOS).save(app/name)


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--edition',choices=['dispatch','driver'],default='dispatch')
    p.add_argument('--site-url',required=True,help='Published HTTPS TaxiFlow site (root URL).')
    p.add_argument('--zig',default=os.getenv('ZIG','zig'))
    p.add_argument('--ld64',default=os.getenv('LD64_LLD','ld64.lld'),help='LLVM Mach-O linker, required on Linux.')
    p.add_argument('--zsign',help='Optional zsign executable: add an ad-hoc signature for re-signing tools (no Apple certificate).')
    p.add_argument('--output',default=str(ROOT/'dist'/'TaxiFlow-1.0-a-signer.ipa'))
    args=p.parse_args()
    site=urlparse(args.site_url)
    if site.scheme!='https' or not site.hostname or site.username or site.password or site.port not in (None,443) or site.path not in ('','/') or site.query or site.fragment:
        p.error('--site-url must be a root HTTPS URL without credentials, path, query or fragment')
    build=ROOT/'build'/args.edition
    app=build/'Payload'/'TaxiFlow.app'
    if app.exists():shutil.rmtree(app)
    app.mkdir(parents=True)
    shutil.copytree(ROOT/'web',app/'web')
    with open(ROOT/'ios'/'Info.plist','rb') as f: info=plistlib.load(f)
    info['CFBundleSupportedPlatforms']=['iPhoneOS']
    info['CFBundleShortVersionString']='2.0.0'
    info['CFBundleVersion']='20'
    info['CFBundleDisplayName']='TaxiFlow Centrale'
    info['TaxiFlowStartURL']=args.site_url.rstrip('/')+('/chauffeur' if args.edition=='driver' else '/centrale')
    info.pop('NSAppTransportSecurity',None)
    info.pop('NSLocalNetworkUsageDescription',None)
    if args.edition=='driver':
        info['CFBundleIdentifier']='app.taxiflow.driver'
        info['CFBundleDisplayName']='TaxiFlow Chauffeur'
        info['CFBundleName']='TaxiFlow Chauffeur'
    (app/'web'/'edition.js').write_text('window.TAXIFLOW_EDITION='+json.dumps(args.edition)+';\n')
    with open(app/'Info.plist','wb') as f:plistlib.dump(info,f,fmt=plistlib.FMT_BINARY)
    (app/'PkgInfo').write_bytes(b'APPL????')
    icons(app,args.edition=='driver')
    source=str(ROOT/'ios'/'main.m')
    binary=str(app/'TaxiFlow')
    env=dict(os.environ)
    if platform.system()=='Darwin':
        sdk=subprocess.check_output(['xcrun','--sdk','iphoneos','--show-sdk-path'],text=True).strip()
        cmd=['xcrun','clang','-arch','arm64','-miphoneos-version-min=15.0','-isysroot',sdk,
             '-DTAXIFLOW_APPLE_SDK','-fobjc-arc','-fblocks','-Os','-Wl,-headerpad,0x4000',source,'-o',binary,
             '-framework','UIKit','-framework','Foundation','-framework','WebKit','-framework','CoreLocation']
    else:
        sdk=build/'stubs';lib=sdk/'usr'/'lib';fw=sdk/'System'/'Library'/'Frameworks'
        write_stub(lib/'libSystem.tbd','/usr/lib/libSystem.B.dylib',symbols=['dyld_stub_binder','___stack_chk_fail','___stack_chk_guard','_memcpy','_memset','__NSConcreteStackBlock','__Block_object_dispose','__Block_object_assign'])
        write_stub(lib/'libobjc.tbd','/usr/lib/libobjc.A.dylib',symbols=['_objc_msgSend','_objc_msgSendSuper2','_objc_retain','_objc_release','_objc_storeStrong','_objc_storeWeak','_objc_loadWeakRetained','_objc_destroyWeak','_objc_retainAutoreleasedReturnValue','_objc_unsafeClaimAutoreleasedReturnValue','_objc_autoreleaseReturnValue','_objc_retainBlock','_objc_autoreleasePoolPush','_objc_autoreleasePoolPop','_objc_alloc','_objc_alloc_init','_objc_opt_class','__objc_empty_cache','__objc_empty_vtable','___objc_personality_v0'])
        frameworks={
          'Foundation':(['NSObject','NSString','NSNumber','NSArray','NSDictionary','NSURL','NSURLRequest','NSBundle','NSJSONSerialization','NSData'],['_NSStringFromClass','_NSTemporaryDirectory']),
          'CoreFoundation':([],['___CFConstantStringClassReference']),
          'UIKit':(['UIColor','UIViewController','UIWindow','UIScreen','UIApplication','UIActivityViewController'],['_UIApplicationMain']),
          'WebKit':(['WKWebView','WKWebViewConfiguration'],[]),
          'CoreLocation':(['CLLocationManager'],[])}
        for name,(classes,symbols) in frameworks.items():
            write_stub(fw/(name+'.framework')/(name+'.tbd'),'/System/Library/Frameworks/'+name+'.framework/'+name,classes,symbols)
        env.setdefault('ZIG_GLOBAL_CACHE_DIR',str(build/'zig-cache'))
        env.setdefault('ZIG_LOCAL_CACHE_DIR',str(build/'zig-local'))
        obj=str(build/'main.o')
        subprocess.run([args.zig,'cc','-target','aarch64-ios.15.0','-fobjc-arc','-fblocks',
                        '-Os','-fno-stack-protector','-c',source,'-o',obj],check=True,env=env)
        cmd=[args.ld64,'-arch','arm64','-platform_version','ios','15.0','15.0',
             '-headerpad','0x4000','-o',binary,obj,'-L'+str(lib),'-F'+str(fw),'-lSystem','-lobjc']
        for name in frameworks:cmd+=['-framework',name]
    subprocess.run(cmd,check=True,env=env)
    Path(binary).chmod(0o755)
    if args.zsign:
        subprocess.run([args.zsign,'-a','-f','-b',info['CFBundleIdentifier'],str(app)],check=True)
    output=Path(args.output).resolve();output.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
        for file in sorted(app.rglob('*')):
            if file.is_file():z.write(file,file.relative_to(build))
    print(output)
    print('ARM64 iOS 15+ build. Requires signing / provisioning before installing. No device test performed.')


if __name__=='__main__':main()
