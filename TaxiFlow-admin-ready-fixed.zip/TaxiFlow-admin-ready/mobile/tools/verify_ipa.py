import struct,hashlib,zipfile,plistlib,sys
from pathlib import Path
p=Path(sys.argv[1])
with zipfile.ZipFile(p) as z:
 b=z.read('Payload/TaxiFlow.app/TaxiFlow');info=z.read('Payload/TaxiFlow.app/Info.plist');resources=z.read('Payload/TaxiFlow.app/_CodeSignature/CodeResources')
 metadata=plistlib.loads(info)
 assert metadata['CFBundleShortVersionString']=='2.0.0'
 assert metadata['TaxiFlowStartURL'].startswith('https://')
 assert metadata['TaxiFlowStartURL'].endswith(('/chauffeur','/centrale'))
 assert 'NSAppTransportSecurity' not in metadata
 manifest=plistlib.loads(resources)
 for key,val in manifest.get('files2',{}).items():
  if isinstance(val,dict) and 'hash2' in val:
   assert hashlib.sha256(z.read('Payload/TaxiFlow.app/'+key)).digest()==val['hash2'],key
 n,size=struct.unpack_from('<II',b,16);pos=32
 for _ in range(n):
  cmd,sz=struct.unpack_from('<II',b,pos)
  if cmd==25:
   name,va,vs,fo,fs=struct.unpack_from('<16s4Q',b,pos+8)
   assert va%16384==0 and fo%16384==0, 'Segment address alignment'
   if name.rstrip(b'\0') not in (b'__LINKEDIT',b'__PAGEZERO'):
    assert vs%16384==0 and fs%16384==0, 'Segment size alignment'
  if cmd==0x1d:off,length=struct.unpack_from('<II',b,pos+8)
  pos+=sz
 magic,total,count=struct.unpack_from('>III',b,off);assert magic==0xfade0cc0
 checked=0
 for i in range(count):
  slot,offset=struct.unpack_from('>II',b,off+12+i*8)
  cd=off+offset
  if struct.unpack_from('>I',b,cd)[0]!=0xfade0c02:continue
  _,ln,ver,flags,ho,ident,ns,nc,limit=struct.unpack_from('>9I',b,cd)
  hs,ht,pl,pg=struct.unpack_from('>4B',b,cd+36)
  h=hashlib.sha256 if ht==2 else hashlib.sha1
  for j in range(nc):
   expected=b[cd+ho+j*hs:cd+ho+(j+1)*hs]
   assert h(b[j*(1<<pg):min((j+1)*(1<<pg),limit)]).digest()==expected
  assert h(info).digest()==b[cd+ho-hs:cd+ho]
  assert h(resources).digest()==b[cd+ho-3*hs:cd+ho-2*hs]
  checked+=1
 assert checked
 print('Mach-O code-page hashes, Info.plist and resource-manifest hashes: PASS')

print('Static checks passed; acceptance by iOS and device launch remain untested.')
