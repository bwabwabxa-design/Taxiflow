#import "AppleInterfaces.h"

@interface TFController : UIViewController <WKScriptMessageHandler, WKNavigationDelegate, CLLocationManagerDelegate>
@property(nonatomic,strong) WKWebView *web;
@property(nonatomic,strong) CLLocationManager *location;
@property(nonatomic,strong) NSURL *startURL;
@property(nonatomic,strong) NSURL *fallbackURL;
@property BOOL gpsRequested;
- (void)stopGPS;
- (void)loadStart;
@end

@implementation TFController
- (BOOL)isTrustedURL:(NSURL*)url {
    return [url.scheme isEqualToString:@"https"] && [url.host isEqualToString:self.startURL.host] && (!url.port || url.port.integerValue == 443);
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:0.973 green:0.973 blue:0.965 alpha:1];
    self.startURL = [NSURL URLWithString:[[NSBundle mainBundle] objectForInfoDictionaryKey:@"TaxiFlowStartURL"]];
    self.fallbackURL = [[NSBundle mainBundle] URLForResource:@"index" withExtension:@"html" subdirectory:@"web"];
    WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
    config.applicationNameForUserAgent = @"TaxiFlow/2.0 (iOS)";
    [config.userContentController addScriptMessageHandler:self name:@"taxiflow"];
    self.web = [[WKWebView alloc] initWithFrame:self.view.bounds configuration:config];
    self.web.autoresizingMask = 2 | 16;
    self.web.navigationDelegate = self;
    self.web.scrollView.contentInsetAdjustmentBehavior = 2;
    self.web.scrollView.bounces = NO;
    self.web.backgroundColor = self.view.backgroundColor;
    [self.view addSubview:self.web];
    self.location = [[CLLocationManager alloc] init];
    self.location.delegate = self;
    self.location.desiredAccuracy = 10;
    self.location.distanceFilter = 15;
    [self loadStart];
}
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    self.web.frame = self.view.bounds;
}
- (void)loadStart {
    if ([self.startURL.scheme isEqualToString:@"https"] && self.startURL.host.length > 0)
        [self.web loadRequest:[NSURLRequest requestWithURL:self.startURL]];
    else [self showFallback];
}
- (void)showFallback {
    [self stopGPS];
    [self.web loadFileURL:self.fallbackURL allowingReadAccessToURL:self.fallbackURL];
}
- (void)sendLocationMessage:(NSDictionary*)value {
    NSData *data = [NSJSONSerialization dataWithJSONObject:value options:0 error:NULL];
    NSString *json = [[NSString alloc] initWithData:data encoding:4];
    [self.web evaluateJavaScript:[NSString stringWithFormat:@"window.taxiGPS && window.taxiGPS(%@);",json] completionHandler:nil];
}
- (void)stopGPS {
    self.gpsRequested = NO;
    [self.location stopUpdatingLocation];
}
- (void)openExternal:(NSURL*)url {
    if ([url.scheme isEqualToString:@"https"] || [url.scheme isEqualToString:@"tel"])
        [[UIApplication sharedApplication] openURL:url options:[NSDictionary dictionary] completionHandler:nil];
}
- (void)userContentController:(WKUserContentController*)controller didReceiveScriptMessage:(WKScriptMessage*)message {
    if (!message.frameInfo.isMainFrame || ![message.body isKindOfClass:[NSDictionary class]]) return;
    NSDictionary *body = message.body;
    NSString *action = body[@"action"];
    if (![action isKindOfClass:[NSString class]]) return;
    NSURL *source = message.frameInfo.request.URL;
    BOOL local = source.isFileURL && [source.path isEqualToString:self.fallbackURL.path];
    if (local && [action isEqualToString:@"retry"]) { [self loadStart]; return; }
    if (![self isTrustedURL:source]) return;
    if ([action isEqualToString:@"startGPS"]) {
        self.gpsRequested = YES;
        CLAuthorizationStatus status = self.location.authorizationStatus;
        if (status == 0) [self.location requestWhenInUseAuthorization];
        else if (status == 3 || status == 4) [self.location startUpdatingLocation];
        else { [self stopGPS]; [self sendLocationMessage:@{@"error": @"Autorise TaxiFlow dans Réglages > Confidentialité > Service de localisation."}]; }
    } else if ([action isEqualToString:@"stopGPS"]) {
        [self stopGPS];
    } else if ([action isEqualToString:@"share"] || [action isEqualToString:@"sharePDF"]) {
        BOOL isPDF = [action isEqualToString:@"sharePDF"];
        NSString *name = body[@"name"], *content = body[isPDF ? @"base64" : @"content"];
        if (![name isKindOfClass:[NSString class]] || ![content isKindOfClass:[NSString class]]) return;
        if (content.length > 10000000 || name.length > 100) return;
        NSURL *url = [NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent:name.lastPathComponent]];
        NSData *fileData = isPDF ? [[NSData alloc] initWithBase64EncodedString:content options:0] : [content dataUsingEncoding:4];
        if (!fileData || ![fileData writeToURL:url options:0x20000000 error:NULL]) return;
        UIActivityViewController *share = [[UIActivityViewController alloc] initWithActivityItems:@[url] applicationActivities:nil];
        share.popoverPresentationController.sourceView = self.view;
        CGRect rect = self.view.bounds;
        rect.origin.x = rect.size.width/2;
        rect.origin.y = rect.size.height/2;
        rect.size.width = 1;
        rect.size.height = 1;
        share.popoverPresentationController.sourceRect = rect;
        [self presentViewController:share animated:YES completion:nil];
    } else if ([action isEqualToString:@"open"]) {
        NSString *string = body[@"url"];
        if ([string isKindOfClass:[NSString class]]) [self openExternal:[NSURL URLWithString:string]];
    }
}
- (void)webView:(WKWebView*)webView decidePolicyForNavigationAction:(WKNavigationAction*)action decisionHandler:(void(^)(WKNavigationActionPolicy))decisionHandler {
    NSURL *url = action.request.URL;
    if ([self isTrustedURL:url] || (url.isFileURL && [url.path isEqualToString:self.fallbackURL.path])) {
        decisionHandler(WKNavigationActionPolicyAllow);
    } else {
        decisionHandler(WKNavigationActionPolicyCancel);
        [self openExternal:url];
    }
}
- (void)webView:(WKWebView*)webView didFailProvisionalNavigation:(id)navigation withError:(NSError*)error {
    if (error.code != -999) [self showFallback];
}
- (void)webView:(WKWebView*)webView didFailNavigation:(id)navigation withError:(NSError*)error {
    if (error.code != -999) [self showFallback];
}
- (void)webViewWebContentProcessDidTerminate:(WKWebView*)webView { [self showFallback]; }
- (void)locationManagerDidChangeAuthorization:(CLLocationManager*)manager {
    if (!self.gpsRequested) return;
    if (manager.authorizationStatus == 3 || manager.authorizationStatus == 4) [manager startUpdatingLocation];
    else if (manager.authorizationStatus == 1 || manager.authorizationStatus == 2) {
        [self stopGPS];
        [self sendLocationMessage:@{@"error": @"Accès à la position refusé. Autorise-le dans les réglages iOS."}];
    }
}
- (void)locationManager:(CLLocationManager*)manager didUpdateLocations:(NSArray*)locations {
    if (!self.gpsRequested) return;
    CLLocation *last = locations.lastObject;
    if (!last || last.horizontalAccuracy < 0 || last.timestamp.timeIntervalSinceNow < -30) return;
    CLLocationCoordinate2D p = last.coordinate;
    [self sendLocationMessage:@{@"lat": @(p.latitude), @"lon": @(p.longitude), @"accuracy": @(last.horizontalAccuracy)}];
}
- (void)locationManager:(CLLocationManager*)manager didFailWithError:(NSError*)error {
    [self sendLocationMessage:@{@"error": error.localizedDescription}];
}
@end

@interface TFAppDelegate : NSObject <UIApplicationDelegate>
@property(nonatomic,strong) UIWindow *window;
@property(nonatomic,strong) TFController *controller;
@end
@implementation TFAppDelegate
- (BOOL)application:(UIApplication*)application didFinishLaunchingWithOptions:(NSDictionary*)options {
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.controller = [[TFController alloc] init];
    self.window.rootViewController = self.controller;
    [self.window makeKeyAndVisible];
    return YES;
}
- (void)applicationDidEnterBackground:(UIApplication*)application {
    [self.controller stopGPS];
    [self.controller.web evaluateJavaScript:@"window.taxiGPSStopped && window.taxiGPSStopped();" completionHandler:nil];
}
@end

int main(int argc, char **argv) {
    @autoreleasepool { return UIApplicationMain(argc, argv, nil, NSStringFromClass([TFAppDelegate class])); }
}
