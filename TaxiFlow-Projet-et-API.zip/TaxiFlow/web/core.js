/* Pure local demo operations. The server independently validates every real operation. */
'use strict';
const TF = (() => {
  const active = ['assigned','en_route','on_board'];
  const labels = {pending:'À attribuer',scheduled:'Réservée',assigned:'Attribuée',en_route:'En approche',on_board:'À bord',completed:'Terminée',cancelled:'Annulée',available:'Disponible',busy:'En course',break:'En pause',offline:'Hors ligne'};
  const categories = {standard:'Berline',van:'Van',pmr:'PMR'};
  const payments = {cash:'Espèces',card:'Carte',account:'Compte client'};
  const settings = {company:'TaxiFlow',currency:'EUR',base:3,per_km:1.8,per_minute:0.35,minimum:8,van_extra:10};
  const places = [
    {label:'Gare de Lyon, Paris',lat:48.8449,lon:2.3735},
    {label:'Aéroport Paris-Orly, Terminal 3',lat:48.7285,lon:2.3629},
    {label:'Gare du Nord, Paris',lat:48.8809,lon:2.3553},
    {label:'Place de la République, Paris',lat:48.8674,lon:2.3638},
    {label:'Tour Eiffel, Paris',lat:48.8584,lon:2.2945},
    {label:'Gare Montparnasse, Paris',lat:48.8408,lon:2.3208},
    {label:'Aéroport Charles de Gaulle, Terminal 2',lat:49.0048,lon:2.5710},
    {label:'Château de Versailles',lat:48.8049,lon:2.1204},
    {label:'Opéra Garnier, Paris',lat:48.8719,lon:2.3316},
    {label:'La Défense, Parvis',lat:48.8919,lon:2.2370},
    {label:'Hôpital Necker, Paris',lat:48.8454,lon:2.3145},
    {label:'Place de la Bastille, Paris',lat:48.8530,lon:2.3690}
  ];
  const id = prefix => prefix+'_'+(globalThis.crypto?.randomUUID?.() || Date.now().toString(36)+Math.random().toString(36).slice(2)).slice(0,12);
  const now = () => new Date().toISOString();
  function km(a,b) {
    const rad=x=>x*Math.PI/180, x=rad(b.lat-a.lat), y=rad(b.lon-a.lon);
    return 12742*Math.asin(Math.min(1,Math.sqrt(Math.sin(x/2)**2+Math.cos(rad(a.lat))*Math.cos(rad(b.lat))*Math.sin(y/2)**2)));
  }
  function quote(p,d,category,s=settings) {
    const distance_km=Math.round(km(p,d)*1.35*100)/100, duration_min=Math.round(distance_km/25*60);
    return {distance_km,duration_min,fare_cents:Math.round(Math.max(s.minimum,s.base+distance_km*s.per_km+duration_min*s.per_minute+(category==='van'?s.van_extra:0))*100),approximate:true,source:'approximation',geometry:null};
  }
  const compatible=(d,t)=>d.status==='available' && d.seats>=t.passengers && (t.category==='standard'||d.category===t.category);
  function seed() {
    const drivers=[
      ['Alex Martin','TX-01','Toyota Corolla','standard',4,48.854,2.348,'available'],
      ['Nora Bernard','TX-02','Mercedes Classe V','van',7,48.874,2.359,'available'],
      ['Samir Laurent','TX-03','Toyota Prius','standard',4,48.844,2.338,'busy'],
      ['Lina Moreau','TX-04','Peugeot e-Traveller','pmr',4,48.868,2.322,'available'],
      ['Hugo Petit','TX-05','Tesla Model 3','standard',4,48.862,2.378,'available'],
      ['Jade Robert','TX-06','Hyundai Ioniq 5','standard',4,48.850,2.309,'break']
    ].map((d,i)=>({id:'drv_demo'+i,name:d[0],callsign:d[1],vehicle:d[2],category:d[3],seats:d[4],lat:d[5],lon:d[6],status:d[7],phone:'',plate:'DÉMO-'+(i+1),notes:'Chauffeur fictif',location_updated_at:now()}));
    const customers=[{id:'cli_demo1',name:'Camille Durand',phone:'',notes:'Client de démonstration',created_at:now()}, {id:'cli_demo2',name:'Hôtel Les Jardins · Démo',phone:'',notes:'Accueil côté cour · compte entreprise fictif',created_at:now()}];
    function trip(n,p,d,status,minutes,extra={}) {
      const created_at=new Date(Date.now()+minutes*60000).toISOString();
      return {id:'trp_demo'+n,passenger:['Camille Durand','Thomas Leroy','Emma Dubois','Louis Garcia','Zoé Michel'][n%5],phone:'',pickup:places[p],destination:places[d],category:'standard',passengers:2,bags:1,priority:'normal',notes:'Course de démonstration',driver_id:null,scheduled_at:null,customer_id:null,payment_method:'card',payment_status:'unpaid',status,version:1,created_at,updated_at:created_at,...quote(places[p],places[d],'standard'),...extra};
    }
    const trips=[trip(1,0,1,'pending',-6,{priority:'urgent'}),trip(2,3,4,'pending',-3),trip(3,8,5,'en_route',-12,{driver_id:drivers[2].id}),trip(4,9,6,'scheduled',0,{category:'van',passengers:5,scheduled_at:new Date(Date.now()+2*3600000).toISOString()})];
    for(let i=0;i<14;i++) {
      const t=trip(10+i,i%10,(i+3)%10,'completed',-60-(i%7)*1440,{driver_id:drivers[i%6].id});
      t.completed_at=t.created_at;
      if(i!==0){t.payment_status='paid';t.paid_cents=t.fare_cents;t.paid_at=t.created_at;}
      trips.push(t);
    }
    return {drivers,trips,customers,settings:{...settings},audit:[],user:{id:'demo',name:'Mode démo',role:'admin',driver_id:null}};
  }
  function log(s,action,target,detail=''){s.audit.unshift({at:now(),action,target,detail,actor:'demo'});s.audit=s.audit.slice(0,150);}
  function assign(s,t,driverId) {
    if(!['pending','scheduled'].includes(t.status))throw Error('Cette course est déjà attribuée ou terminée.');
    if(t.scheduled_at&&new Date(t.scheduled_at).getTime()>Date.now()+1800000)throw Error('L’attribution s’ouvre 30 minutes avant le départ.');
    let ds=s.drivers.filter(d=>compatible(d,t));
    if(driverId)ds=ds.filter(d=>d.id===driverId);
    else ds=ds.filter(d=>d.lat!=null).sort((a,b)=>km(a,t.pickup)-km(b,t.pickup));
    if(!ds.length)throw Error('Aucun chauffeur compatible disponible.');
    t.driver_id=ds[0].id;t.status='assigned';t.version++;t.updated_at=now();ds[0].status='busy';log(s,'trip.assigned',t.id,ds[0].name);return t;
  }
  function transition(s,t,status) {
    const next={pending:['cancelled'],scheduled:['cancelled'],assigned:['en_route','cancelled'],en_route:['on_board','cancelled'],on_board:['completed'],completed:[],cancelled:[]};
    if(!next[t.status].includes(status))throw Error('Cette transition de course est impossible.');
    t.status=status;t.version++;t.updated_at=now();
    if(['completed','cancelled'].includes(status)&&t.driver_id)s.drivers.find(d=>d.id===t.driver_id).status='available';
    if(status==='completed')t.completed_at=now();log(s,'trip.'+status,t.id);return t;
  }
  function csv(trips){
    const safe=x=>'"'+String(x??'').replace(/^[=+\-@\t\r]/,"'$&").replaceAll('"','""')+'"';
    return '\uFEFF'+[['Référence','Client','Départ','Arrivée','Statut','Estimation EUR','Encaissé EUR','Paiement','Date'],...trips.map(t=>[t.id,t.passenger,t.pickup.label,t.destination.label,labels[t.status],t.fare_cents/100,(t.paid_cents||0)/100,t.payment_status,t.created_at])].map(r=>r.map(safe).join(';')).join('\r\n');
  }
  return {active,labels,categories,payments,settings,places,id,now,km,quote,seed,compatible,assign,transition,csv,log};
})();
if(typeof module!=='undefined')module.exports=TF;
