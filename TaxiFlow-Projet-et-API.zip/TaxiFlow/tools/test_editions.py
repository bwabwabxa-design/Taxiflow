from playwright.sync_api import sync_playwright,expect
from pathlib import Path
import os
BASE=os.getenv('BASE_URL','http://127.0.0.1:8766')
OUT=Path(__file__).resolve().parent.parent/'build'/'qa';OUT.mkdir(parents=True,exist_ok=True)
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,args=['--no-sandbox']);ctx=b.new_context(viewport={'width':390,'height':844},geolocation={'latitude':48.8049,'longitude':2.1204,'accuracy':8},permissions=['geolocation'])
 page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.route('**/edition.js',lambda r:r.fulfill(content_type='application/javascript',body="window.TAXIFLOW_EDITION='driver';"))
 page.goto(BASE);expect(page.get_by_role('heading',name='Votre espace chauffeur')).to_be_visible()
 assert page.locator('button[data-page="fleet"]').count()==0
 page.get_by_role('button',name='Partager ma position',exact=True).click();page.get_by_role('button',name='Activer le GPS',exact=True).click()
 expect(page.locator('#gps-live-info')).to_contain_text('48.80490')
 page.screenshot(path=str(OUT/'chauffeur-gps.png'),full_page=True)
 page.get_by_role('button',name='Gérer la course').click();page.get_by_role('button',name='Je suis arrivé',exact=True).click()
 expect(page.get_by_text('Arrivée signalée',exact=True)).to_be_visible()
 page.get_by_role('button',name='Client à bord',exact=True).click();page.get_by_role('button',name='Terminer la course',exact=True).click()
 with page.expect_download() as dl:page.get_by_role('button',name='Document PDF',exact=True).click()
 dl.value.save_as(str(OUT/'course-test.pdf'))
 page.get_by_role('button',name='Fermer',exact=True).click();page.locator('button[data-page="history"]').last.click();expect(page.get_by_role('heading',name='Mon historique')).to_be_visible()
 # dispatcher workflow for recurring trips and incoming customer requests
 second=ctx.new_page();second.on('pageerror',lambda e:errors.append(str(e)));second.goto(BASE)
 second.locator('[data-action="new-trip"]').first.click();second.fill('#passenger','Série test');second.fill('#pickup','Gare de Lyon');second.locator('[data-pick-address="pickup"]').first.click();second.fill('#destination','Orly');second.locator('[data-pick-address="destination"]').first.click()
 second.fill('#scheduled','2027-01-05T08:00');second.select_option('#repeat','weekly');second.fill('#repeat-count','3');second.get_by_role('button',name='Créer la course').click();expect(second.get_by_role('heading',name='Vos trajets réguliers')).to_be_visible();expect(second.get_by_text('3 départs · 3 réservations restantes')).to_be_visible()
 second.locator('[data-action="more"]').click();second.get_by_role('button',name='Demandes clients').click();second.get_by_role('button',name='Essayer une demande client').click();second.fill('#passenger','Client test');second.fill('#pickup','Gare de Lyon');second.locator('[data-pick-address="pickup"]').first.click();second.fill('#destination','Orly');second.locator('[data-pick-address="destination"]').first.click();second.get_by_role('button',name='Créer la course').click();second.locator('[data-booking-decision][data-accept="yes"]').click();expect(second.get_by_text('Acceptée',exact=True)).to_be_visible()
 second.screenshot(path=str(OUT/'dispatch-demandes.png'),full_page=True)
 assert not errors,errors
 assert second.evaluate('document.documentElement.scrollWidth<=innerWidth')
 print('Driver GPS, arrival, lifecycle, PDF, history; dispatcher recurrence and booking: PASS')
 b.close()
