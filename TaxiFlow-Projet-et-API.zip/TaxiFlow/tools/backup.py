"""Online, consistent SQLite backup. Existing output is never overwritten."""
import argparse
import os
from pathlib import Path
import sqlite3

p=argparse.ArgumentParser()
p.add_argument('output',help='New backup .sqlite3 file')
p.add_argument('--database',default=os.getenv('TAXIFLOW_DB',str(Path(__file__).resolve().parent.parent/'api'/'data'/'taxiflow.sqlite3')))
a=p.parse_args()
src=Path(a.database).resolve();out=Path(a.output).resolve()
if not src.is_file():raise SystemExit('Base introuvable.')
out.parent.mkdir(parents=True,exist_ok=True)
fd=os.open(out,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
os.close(fd)
try:
    with sqlite3.connect(src.as_uri()+'?mode=ro',uri=True) as original,sqlite3.connect(out) as backup:
        original.backup(backup)
        if backup.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise RuntimeError('Sauvegarde incohérente.')
except Exception:
    out.unlink(missing_ok=True)
    raise
print('Sauvegarde créée :',out)
