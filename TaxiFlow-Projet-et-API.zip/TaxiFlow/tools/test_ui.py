"""Run against a local server: BASE_URL=http://127.0.0.1:8765 python tools/test_ui.py."""
import json
import os
from pathlib import Path
from playwright.sync_api import sync_playwright, expect

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'build'/'qa'
OUT.mkdir(parents=True,exist_ok=True)
BASE=os.getenv('BASE_URL','http://127.0.0.1:8765')


with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=2,is_mobile=True,has_touch=True)
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto(BASE,wait_until='networkidle')
    expect(page.get_by_role('heading',name='Le dispatch, en un regard.')).to_be_visible()
    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
    page.screenshot(path=str(OUT/'iphone-dispatch.png'),full_page=True)
    page.click('button[data-action="new-trip"]')
    page.fill('#passenger','Test UI Camille')
    page.fill('#pickup','Gare de Lyon')
    page.click('button[data-pick-address="pickup"]')
    page.fill('#destination','Orly')
    page.click('button[data-pick-address="destination"]')
    page.screenshot(path=str(OUT/'iphone-creation.png'),full_page=True)
    page.get_by_role('button',name='Créer la course').click()
    expect(page.locator('.modal')).to_have_count(0)
    created=page.evaluate("JSON.parse(localStorage.getItem('tf-demo-v1')).trips.find(t=>t.passenger==='Test UI Camille')")
    assert created and created['status']=='pending'
    tid=created['id']
    page.locator(f'button[data-trip="{tid}"]').first.click()
    page.locator(f'button[data-assign="{tid}"]').first.click()
    page.get_by_role('button',name='Accepter la mission',exact=True).click()
    expect(page.get_by_role('button',name='Partir vers le client')).to_be_visible()
    page.get_by_role('button',name='Partir vers le client').click()
    page.get_by_role('button',name='Client à bord',exact=True).click()
    page.get_by_role('button',name='Terminer la course').click()
    page.fill('#paid-amount','32.50')
    page.locator('input[type="checkbox"]').check()
    page.get_by_role('button',name='Enregistrer le paiement reçu').click()
    expect(page.get_by_role('button',name='Exporter le récapitulatif')).to_be_visible()
    with page.expect_download() as dl:
        page.get_by_role('button',name='Exporter le récapitulatif').click()
    assert dl.value.suggested_filename.endswith('.txt')
    page.get_by_role('button',name='Fermer',exact=True).first.click()
    saved=page.evaluate("JSON.parse(localStorage.getItem('tf-demo-v1'))")
    trip=next(t for t in saved['trips'] if t['id']==tid)
    assert trip['status']=='completed' and trip['paid_cents']==3250
    assert next(d for d in saved['drivers'] if d['id']==trip['driver_id'])['status']=='available'
    page.locator('.bottom-nav [data-page="trips"]').click()
    page.click('[data-filter="completed"]')
    page.fill('#trip-search','Test UI Camille')
    expect(page.locator('.trip-mobile')).to_have_count(1)
    page.locator('.bottom-nav [data-action="more"]').click()
    page.locator('.modal [data-page="customers"]').click()
    page.click('[data-action="add-customer"]')
    page.fill('#c-name','<img src=x onerror=alert(1)>')
    page.fill('#c-notes','Texte spécial < & >')
    page.get_by_role('button',name='Créer la fiche client').click()
    expect(page.locator('.customer-card img')).to_have_count(0)
    expect(page.get_by_text('<img src=x onerror=alert(1)>',exact=True)).to_be_visible()
    page.locator('.bottom-nav [data-page="fleet"]').click()
    page.click('[data-action="add-driver"]')
    page.fill('#d-name','Chauffeur UI')
    page.fill('#d-callsign','TX-99')
    page.fill('#d-vehicle','Voiture test')
    page.get_by_role('button',name='Ajouter à la flotte').click()
    expect(page.get_by_role('heading',name='Chauffeur UI')).to_be_visible()
    card=page.locator('.driver-card').filter(has=page.get_by_role('heading',name='Chauffeur UI'))
    card.locator('select').select_option('available')
    expect(card.locator('.badge.available')).to_be_visible()
    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
    page.locator('.bottom-nav [data-page="finance"]').click()
    page.screenshot(path=str(OUT/'iphone-finance.png'),full_page=True)
    with page.expect_download() as dl:
        page.get_by_role('button',name='Exporter les courses en CSV').click()
    assert dl.value.suggested_filename=='taxiflow-courses.csv'
    page.reload(wait_until='networkidle')
    assert page.evaluate("JSON.parse(localStorage.getItem('tf-demo-v1')).trips.some(t=>t.passenger==='Test UI Camille' && t.paid_cents===3250)")
    # Desktop and keyboard accessible layout.
    desktop=browser.new_page(viewport={'width':1440,'height':1050},device_scale_factor=1)
    desktop.on('pageerror',lambda e:errors.append(str(e)))
    desktop.goto(BASE,wait_until='networkidle')
    desktop.screenshot(path=str(OUT/'desktop-dispatch.png'),full_page=True)
    assert desktop.evaluate('document.documentElement.scrollWidth <= innerWidth')
    for key in ['trips','fleet','customers','finance','driver','settings']:
        desktop.locator('.sidebar [data-page="'+key+'"]').click()
        assert desktop.evaluate('document.documentElement.scrollWidth <= innerWidth'),key
    assert not errors,errors
    browser.close()
    print(json.dumps({'result':'passed','checks':['mobile layout','create trip','automatic assignment','full trip lifecycle','record payment','receipt export','CSV export','search','customer XSS escaping','add driver','availability','persistence','desktop navigation'],'javascript_errors':errors},ensure_ascii=False))
