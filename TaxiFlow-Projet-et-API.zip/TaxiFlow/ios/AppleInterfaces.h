/* Minimal public API declarations for the Linux build. No Apple SDK is redistributed.
 * On a Mac, TAXIFLOW_APPLE_SDK uses the platform's authoritative headers instead. */
#ifdef TAXIFLOW_APPLE_SDK
#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
#import <CoreLocation/CoreLocation.h>
#else
typedef signed long NSInteger;
typedef unsigned long NSUInteger;
typedef double CGFloat;
typedef _Bool BOOL;
#define YES ((_Bool)1)
#define NO ((_Bool)0)
#define nil ((id)0)
#define NULL ((void*)0)
typedef struct { CGFloat x,y; } CGPoint;
typedef struct { CGFloat width,height; } CGSize;
typedef struct { CGPoint origin; CGSize size; } CGRect;
typedef struct { double latitude,longitude; } CLLocationCoordinate2D;
typedef NSInteger CLAuthorizationStatus;
typedef NSInteger WKNavigationActionPolicy;
static const NSInteger WKNavigationActionPolicyCancel=0;
static const NSInteger WKNavigationActionPolicyAllow=1;
@class NSString, NSArray, NSDictionary, NSURL, NSData, NSError, UIColor, UIViewController, UIScrollView;
@protocol NSObject @end
@interface NSObject <NSObject> {
    Class isa; // NSObject object header: never use offset zero for a strong ivar.
}
+ (id)alloc;
+ (Class)class;
- (id)init;
- (BOOL)isKindOfClass:(Class)c;
@end
@interface NSString : NSObject
@property(readonly) NSUInteger length;
@property(readonly) NSString *lastPathComponent;
+ (instancetype)stringWithFormat:(NSString*)format, ...;
- (instancetype)initWithData:(NSData*)data encoding:(NSUInteger)encoding;
- (BOOL)isEqualToString:(NSString*)s;
- (BOOL)hasPrefix:(NSString*)s;
- (NSString*)stringByAppendingPathComponent:(NSString*)s;
- (NSData*)dataUsingEncoding:(NSUInteger)encoding;
@end
@interface NSNumber : NSObject
+ (NSNumber*)numberWithDouble:(double)n;
+ (NSNumber*)numberWithBool:(BOOL)n;
@end
@interface NSArray : NSObject
@property(readonly) id lastObject;
+ (instancetype)arrayWithObjects:(const id[])objects count:(NSUInteger)count;
@end
@interface NSDictionary : NSObject
+ (instancetype)dictionary;
+ (instancetype)dictionaryWithObjects:(const id[])objects forKeys:(const id[])keys count:(NSUInteger)count;
- (id)objectForKeyedSubscript:(id)key;
@end
@interface NSURL : NSObject
@property(readonly) NSString *scheme;
@property(readonly) NSString *path;
@property(readonly) BOOL isFileURL;
+ (instancetype)URLWithString:(NSString*)s;
+ (instancetype)fileURLWithPath:(NSString*)path;
@end
@interface NSURLRequest : NSObject
@property(readonly) NSURL *URL;
@end
@interface NSError : NSObject
@property(readonly) NSString *localizedDescription;
@end
@interface NSData : NSObject
- (instancetype)initWithBase64EncodedString:(NSString*)string options:(NSUInteger)options;
- (BOOL)writeToURL:(NSURL*)url options:(NSUInteger)options error:(NSError**)error;
@end
@interface NSJSONSerialization : NSObject
+ (NSData*)dataWithJSONObject:(id)obj options:(NSUInteger)options error:(NSError**)error;
@end
@interface NSBundle : NSObject
+ (NSBundle*)mainBundle;
@property(readonly) NSURL *resourceURL;
- (NSURL*)URLForResource:(NSString*)name withExtension:(NSString*)ext subdirectory:(NSString*)dir;
@end
extern NSString *NSTemporaryDirectory(void);
extern NSString *NSStringFromClass(Class cls);
@interface UIColor : NSObject
+ (UIColor*)colorWithRed:(CGFloat)r green:(CGFloat)g blue:(CGFloat)b alpha:(CGFloat)a;
@end
@interface UIView : NSObject
@property CGRect frame;
@property(readonly) CGRect bounds;
@property NSUInteger autoresizingMask;
@property(nonatomic,strong) UIColor *backgroundColor;
- (id)initWithFrame:(CGRect)frame;
- (void)addSubview:(UIView*)view;
@end
@interface UIPopoverPresentationController : NSObject
@property(nonatomic,strong) UIView *sourceView;
@property CGRect sourceRect;
@end
@interface UIViewController : NSObject
@property(nonatomic,strong) UIView *view;
- (void)viewDidLoad;
- (void)viewDidLayoutSubviews;
- (void)presentViewController:(UIViewController*)controller animated:(BOOL)animated completion:(void(^)(void))completion;
@end
@interface UIScreen : NSObject
+ (UIScreen*)mainScreen;
@property(readonly) CGRect bounds;
@end
@interface UIWindow : UIView
@property(nonatomic,strong) UIViewController *rootViewController;
- (void)makeKeyAndVisible;
@end
@protocol UIApplicationDelegate <NSObject> @end
@interface UIApplication : NSObject
+ (UIApplication*)sharedApplication;
- (void)openURL:(NSURL*)url options:(NSDictionary*)options completionHandler:(void(^)(BOOL))completion;
@end
extern int UIApplicationMain(int argc,char **argv,NSString *principalClassName,NSString *delegateClassName);
@interface UIActivityViewController : UIViewController
- (instancetype)initWithActivityItems:(NSArray*)items applicationActivities:(NSArray*)activities;
@property(readonly) UIPopoverPresentationController *popoverPresentationController;
@end
@interface UIScrollView : UIView
@property NSInteger contentInsetAdjustmentBehavior;
@property BOOL bounces;
@end
@protocol WKScriptMessageHandler <NSObject> @end
@protocol WKNavigationDelegate <NSObject> @end
@interface WKUserContentController : NSObject
- (void)addScriptMessageHandler:(id)handler name:(NSString*)name;
@end
@interface WKWebViewConfiguration : NSObject
@property(nonatomic,strong) WKUserContentController *userContentController;
@property(nonatomic,copy) NSString *applicationNameForUserAgent;
@end
@interface WKFrameInfo : NSObject
@property(readonly) BOOL isMainFrame;
@property(readonly) NSURLRequest *request;
@end
@interface WKScriptMessage : NSObject
@property(readonly) id body;
@property(readonly) WKFrameInfo *frameInfo;
@end
@interface WKNavigationAction : NSObject
@property(readonly) NSURLRequest *request;
@end
@interface WKWebView : UIView
@property(nonatomic,weak) id navigationDelegate;
@property(readonly) UIScrollView *scrollView;
- (instancetype)initWithFrame:(CGRect)frame configuration:(WKWebViewConfiguration*)configuration;
- (id)loadFileURL:(NSURL*)url allowingReadAccessToURL:(NSURL*)accessURL;
- (void)evaluateJavaScript:(NSString*)script completionHandler:(void(^)(id,NSError*))handler;
@end
@protocol CLLocationManagerDelegate <NSObject> @end
@interface CLLocation : NSObject
@property(readonly) CLLocationCoordinate2D coordinate;
@property(readonly) double horizontalAccuracy;
@end
@interface CLLocationManager : NSObject
@property(nonatomic,weak) id delegate;
@property double desiredAccuracy;
@property double distanceFilter;
@property(readonly) CLAuthorizationStatus authorizationStatus;
- (void)requestWhenInUseAuthorization;
- (void)startUpdatingLocation;
- (void)stopUpdatingLocation;
@end
#endif
