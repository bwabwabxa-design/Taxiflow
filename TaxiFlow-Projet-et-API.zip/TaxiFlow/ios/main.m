#import "AppleInterfaces.h"

@interface TFController : UIViewController <WKScriptMessageHandler, WKNavigationDelegate, CLLocationManagerDelegate>
@property(nonatomic,strong) WKWebView *web;
@property(nonatomic,strong) CLLocationManager *location;
@property(nonatomic,strong) NSURL *webDirectory;
@property BOOL gpsRequested;
- (void)stopGPS;
@end

@implementation TFController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:0.957 green:0.965 blue:0.973 alpha:1];
    WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
    config.applicationNameForUserAgent = @"TaxiFlow/1.0 (iOS taxi dispatcher)";
    [config.userContentController addScriptMessageHandler:self name:@"taxiflow"];
    self.web = [[WKWebView alloc] initWithFrame:self.view.bounds configuration:config];
    self.web.autoresizingMask = 2 | 16;
    self.web.navigationDelegate = self;
    self.web.scrollView.contentInsetAdjustmentBehavior = 2;
    self.web.scrollView.bounces = NO;
    self.web.backgroundColor = self.view.backgroundColor;
    [self.view addSubview:self.web];
    self.webDirectory = [NSURL fileURLWithPath:[[[NSBundle mainBundle] resourceURL].path stringByAppendingPathComponent:@"web"]];
    NSURL *index = [[NSBundle mainBundle] URLForResource:@"index" withExtension:@"html" subdirectory:@"web"];
    [self.web loadFileURL:index allowingReadAccessToURL:self.webDirectory];
    self.location = [[CLLocationManager alloc] init];
    self.location.delegate = self;
    self.location.desiredAccuracy = 10;
    self.location.distanceFilter = 15;
}
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    self.web.frame = self.view.bounds;
}
- (void)sendLocationMessage:(NSDictionary*)value {
    NSData *data = [NSJSONSerialization dataWithJSONObject:value options:0 error:NULL];
    NSString *json = [[NSString alloc] initWithData:data encoding:4];
    [self.web evaluateJavaScript:[NSString stringWithFormat:@"window.taxiGPS && window.taxiGPS(%@);",json] completionHandler:nil];
}
- (void)stopGPS {
    self.gpsRequested = NO;
    [self.location stopUpdatingLocation];
}
- (void)userContentController:(WKUserContentController*)controller didReceiveScriptMessage:(WKScriptMessage*)message {
    if (!message.frameInfo.isMainFrame || !message.frameInfo.request.URL.isFileURL) return;
    if (![message.body isKindOfClass:[NSDictionary class]]) return;
    NSDictionary *body = message.body;
    NSString *action = body[@"action"];
    if (![action isKindOfClass:[NSString class]]) return;
    if ([action isEqualToString:@"startGPS"]) {
        self.gpsRequested = YES;
        CLAuthorizationStatus status = self.location.authorizationStatus;
        if (status == 0) [self.location requestWhenInUseAuthorization];
        else if (status == 3 || status == 4) [self.location startUpdatingLocation];
        else [self sendLocationMessage:@{@"error": @"Autorise TaxiFlow dans Réglages > Confidentialité > Service de localisation."}];
    } else if ([action isEqualToString:@"stopGPS"]) {
        [self stopGPS];
    } else if ([action isEqualToString:@"open"]) {
        NSString *string = body[@"url"];
        if (![string isKindOfClass:[NSString class]]) return;
        NSURL *url = [NSURL URLWithString:string];
        if ([url.scheme isEqualToString:@"https"] || [url.scheme isEqualToString:@"tel"])
            [[UIApplication sharedApplication] openURL:url options:[NSDictionary dictionary] completionHandler:nil];
    } else if ([action isEqualToString:@"share"] || [action isEqualToString:@"sharePDF"]) {
        BOOL isPDF = [action isEqualToString:@"sharePDF"];
        NSString *name = body[@"name"], *content = body[isPDF ? @"base64" : @"content"];
        if (![name isKindOfClass:[NSString class]] || ![content isKindOfClass:[NSString class]]) return;
        if (content.length > 10000000 || name.length > 100) return;
        NSURL *url = [NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent:name.lastPathComponent]];
        NSData *fileData = isPDF ? [[NSData alloc] initWithBase64EncodedString:content options:0] : [content dataUsingEncoding:4];
        if (!fileData || ![fileData writeToURL:url options:0x20000000 error:NULL]) return;
        UIActivityViewController *share = [[UIActivityViewController alloc] initWithActivityItems:@[url] applicationActivities:nil];
        share.popoverPresentationController.sourceView = self.view;
        CGRect rect = self.view.bounds;
        rect.origin.x = rect.size.width/2;
        rect.origin.y = rect.size.height/2;
        rect.size.width = 1;
        rect.size.height = 1;
        share.popoverPresentationController.sourceRect = rect;
        [self presentViewController:share animated:YES completion:nil];
    }
}
- (void)webView:(WKWebView*)webView decidePolicyForNavigationAction:(WKNavigationAction*)action decisionHandler:(void(^)(WKNavigationActionPolicy))decisionHandler {
    NSURL *url = action.request.URL;
    NSString *prefix = [self.webDirectory.path stringByAppendingPathComponent:@""];
    if (url.isFileURL && [url.path hasPrefix:prefix]) {
        decisionHandler(WKNavigationActionPolicyAllow);
    } else {
        decisionHandler(WKNavigationActionPolicyCancel);
        if ([url.scheme isEqualToString:@"https"])
            [[UIApplication sharedApplication] openURL:url options:[NSDictionary dictionary] completionHandler:nil];
    }
}
- (void)locationManagerDidChangeAuthorization:(CLLocationManager*)manager {
    if (!self.gpsRequested) return;
    if (manager.authorizationStatus == 3 || manager.authorizationStatus == 4) [manager startUpdatingLocation];
    else if (manager.authorizationStatus == 1 || manager.authorizationStatus == 2) {
        [self stopGPS];
        [self sendLocationMessage:@{@"error": @"Accès à la position refusé. Tu peux l’autoriser dans les réglages iOS."}];
    }
}
- (void)locationManager:(CLLocationManager*)manager didUpdateLocations:(NSArray*)locations {
    if (!self.gpsRequested) return;
    CLLocation *last = locations.lastObject;
    if (last.horizontalAccuracy < 0) return;
    CLLocationCoordinate2D p = last.coordinate;
    [self sendLocationMessage:@{@"lat": @(p.latitude), @"lon": @(p.longitude), @"accuracy": @(last.horizontalAccuracy)}];
}
- (void)locationManager:(CLLocationManager*)manager didFailWithError:(NSError*)error {
    [self sendLocationMessage:@{@"error": error.localizedDescription}];
}
@end

@interface TFAppDelegate : NSObject <UIApplicationDelegate>
@property(nonatomic,strong) UIWindow *window;
@property(nonatomic,strong) TFController *controller;
@end
@implementation TFAppDelegate
- (BOOL)application:(UIApplication*)application didFinishLaunchingWithOptions:(NSDictionary*)options {
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.controller = [[TFController alloc] init];
    self.window.rootViewController = self.controller;
    [self.window makeKeyAndVisible];
    return YES;
}
- (void)applicationDidEnterBackground:(UIApplication*)application {
    [self.controller stopGPS];
    [self.controller.web evaluateJavaScript:@"window.taxiGPSStopped && window.taxiGPSStopped();" completionHandler:nil];
}
@end

int main(int argc, char **argv) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([TFAppDelegate class]));
    }
}
