# TaxiFlow 1.1 · Centrale + Chauffeur

Voir **docs/VERSION-1.1.md** pour les nouveautés, les deux IPA, les tests et la configuration des services. Les sections ci-dessous décrivent aussi le socle 1.0.

# TaxiFlow — dispatch taxi pour iPhone

Application en français, API privée et code source. Version iOS et API 1.1.0.

Voir `docs/CORRECTION-LIVECONTAINER.md` pour la correction du premier IPA.

## Installer l’application

Le fichier `TaxiFlow-1.0-a-signer.ipa` contient une véritable application ARM64 pour iOS 15 ou ultérieur. Il doit être **signé avec un certificat et un profil de provisionnement valides** avant installation, par votre outil habituel de sideload ou votre chaîne de distribution Apple. Aucun certificat, compte Apple ou profil n’est inclus. Ce n’est pas une publication App Store.

L’application démarre sur une **démonstration locale** avec des courses et chauffeurs fictifs. Elle fonctionne sans serveur pour essayer les fonctions. La carte nécessite internet. Le mode démo ne transmet aucune demande à de vrais chauffeurs. Les données de démo restent sur l’appareil et sont séparées du mode connecté.

**La compilation de l’IPA et sa structure ont été vérifiées. Le lancement, le clavier, les autorisations GPS et le partage de fichiers n’ont pas été testés sur un iPhone physique ni dans le simulateur Apple.** Les interfaces et les parcours ont été testés dans Chromium aux formats mobile et ordinateur.

## Ce qui est inclus

- Tableau de bord, carte OpenStreetMap, disponibilités et dernières positions GPS.
- Création de courses immédiates ou réservées, recherche d’adresses françaises, passagers, bagages, priorité et instructions.
- Catégories berline, van et PMR, vérification de capacité.
- Attribution manuelle ou automatique selon la distance à vol d’oiseau, la capacité et la catégorie. En mode connecté, le choix automatique exige une position de moins de 5 minutes.
- Réservations : attribution ouverte 30 minutes avant le départ. L’attribution reste déclenchée par le dispatcheur ; aucun robot ne lance des courses en arrière-plan.
- Cycle attribuée → en approche → à bord → terminée ; annulation avant prise en charge ; libération du chauffeur à la fin.
- Protection contre les doubles attributions et les modifications concurrentes.
- Fiches clients et création de nouveaux chauffeurs.
- Espace chauffeur, appels par l’application Téléphone et ouverture d’Apple Plans.
- Partage GPS volontaire, pendant l’utilisation au premier plan seulement. Le GPS s’arrête en arrière-plan et doit être réactivé au retour.
- Estimations paramétrables, suivi des encaissements réels saisis manuellement, graphique sur 7 jours, CSV et récapitulatifs texte.
- Comptes administrateur, dispatcheur et chauffeur ; journal des actions ; API documentée.
- Actualisation du mode connecté toutes les 10 secondes lorsque l’application est ouverte.

## Connecter une vraie flotte

L’API est fournie **mais n’est pas hébergée**. Pour synchroniser plusieurs appareils, démarrez-la sur votre serveur, activez HTTPS, puis saisissez l’URL et les identifiants dans **Réglages → Connecter mon serveur**.

### Essai de l’API sur ordinateur

Python 3.12 ou ultérieur est recommandé. Depuis le dossier `TaxiFlow` :

```sh
python -m venv .venv
# Windows : .venv\Scripts\activate
# macOS / Linux : source .venv/bin/activate
python -m pip install -r api/requirements.txt
python -m api.manage init --email admin@votre-centrale.fr --name Administrateur
python -m uvicorn api.main:app --host 127.0.0.1 --port 8000 --workers 1
```

La création du compte demande un mot de passe de 12 caractères minimum et sa confirmation. Aucun mot de passe par défaut n’est fourni.

- Interface ordinateur : `http://127.0.0.1:8000`
- Documentation interactive de l’API : `http://127.0.0.1:8000/docs`
- Schéma fourni : `docs/openapi.json`

Une adresse `localhost` n’est utilisable que sur l’ordinateur qui héberge le serveur. Pour l’iPhone, utilisez un domaine HTTPS accessible depuis son réseau.

### Hébergement avec Docker et HTTPS

Le dossier contient `compose.yaml`, `Dockerfile`, `Caddyfile` et `.env.example`.

1. Faites pointer votre domaine vers votre serveur et ouvrez les ports 80 et 443.
2. Copiez `.env.example` vers `.env` et remplacez `DOMAIN` par votre domaine.
3. Exécutez `docker compose up -d --build`.
4. Créez le compte : `docker compose exec api python -m api.manage init --email admin@votre-centrale.fr`.
5. Dans l’IPA, connectez-vous à `https://votre-domaine.fr` (sans `/api/v1`).

Le volume Docker `taxiflow_data` conserve la base SQLite. Sauvegardez-la régulièrement avec l’outil fourni ou une sauvegarde cohérente du volume. Le fichier contient des informations clients ; gardez-le privé.

Pour réinitialiser un mot de passe :

```sh
python -m api.manage reset-password --email admin@votre-centrale.fr
```

Cette action invalide les sessions existantes de ce compte.

### Premiers pas en flotte connectée

1. **Chauffeurs → Ajouter un chauffeur** : renseignez véhicule, catégorie et capacité.
2. **Réglages → Créer un accès** : créez un compte chauffeur associé à sa fiche.
3. Le chauffeur se connecte sur son iPhone, passe en **Disponible** et active le partage GPS.
4. Le dispatch crée une course, valide les deux adresses, puis choisit le chauffeur ou l’attribution automatique.
5. Le chauffeur met à jour la course. L’encaissement peut être enregistré seulement après la fin.

L’utilisateur doit se reconnecter après la fermeture complète de l’application. Les jetons restent en mémoire, et expirent après 12 heures. L’URL du serveur et l’identifiant sont mémorisés ; le mot de passe ne l’est pas.

## API et services cartographiques

| Service | Fonction | Configuration |
|---|---|---|
| API TaxiFlow | Authentification, flotte, clients, courses, paiements enregistrés, journal | Fournie, à héberger |
| IGN Géoplateforme | Recherche d’adresses françaises | `https://data.geopf.fr/geocodage/search` |
| OSRM | Distance et durée routières à la création d’une course | `OSRM_URL`, serveur public par défaut |
| OpenStreetMap | Fond de carte en ligne | Tuiles publiques, attribution affichée |
| Apple Plans | Navigation externe | Ouverture à la demande du chauffeur |

Les services publics cartographiques n’offrent pas de disponibilité garantie pour une exploitation professionnelle. Les politiques de leurs fournisseurs s’appliquent. Pour une flotte en production, configurez votre propre OSRM ou un service contractuel et adaptez le fournisseur de tuiles. Aucun service payant n’est activé et aucune clé commerciale n’est incluse.

Si le routage échoue, la création indique explicitement une distance et une durée **approximatives**. La recherche d’adresse, si indisponible, affiche une erreur. Le mode connecté ne bascule jamais silencieusement sur la démo.

## Limites précises de cette version

- Les estimations sont des calculs internes d’exemple, **pas un taximètre**. Les paramètres ne représentent aucun barème réglementaire validé. Les montants réellement reçus sont saisis séparément.
- Aucun débit de carte, SMS, notification push, compte passager, intégration aéroport ou service de facturation fiscale n’est inclus.
- Les récapitulatifs de course ne sont pas des factures réglementaires.
- Pas de GPS permanent en arrière-plan, ni de notifications lorsque l’app est fermée.
- Un seul serveur / une seule flotte par installation de l’API, un seul processus recommandé. Données chargées en bloc : cette base convient à un prototype ou à une petite flotte, pas à une plateforme à grande échelle sans adaptations.
- Aucun test d’installation Apple, audit indépendant de sécurité ou validation métier n’a été réalisé.

## Organisation des sources

```text
web/                 Interface embarquée, mode démo, client API, Leaflet local
api/                 FastAPI + SQLite et commandes d’administration
api/tests/           Tests des règles métier et des accès
ios/                 Application Objective-C avec WKWebView, GPS et partage iOS
tools/build_ipa.py    Compilation iOS ARM64 et paquet IPA
tools/test_ui.py      Parcours d’interface automatisés
tools/backup.py       Sauvegarde cohérente de SQLite
docs/                API et rapport des vérifications
```

## Recompiler l’IPA

Sur macOS avec Xcode installé :

```sh
python3 -m pip install Pillow
python3 tools/build_ipa.py --output dist/TaxiFlow-1.0-a-signer.ipa
```

Sur Linux avec Zig 0.13.0 (compilation Clang), LLVM LLD 18 et Pillow :

```sh
python3 -m pip install ziglang==0.13.0 Pillow
python3 tools/build_ipa.py --zig /chemin/vers/zig --ld64 /chemin/vers/ld64.lld --output dist/TaxiFlow-1.0-a-signer.ipa
```

La compilation Linux utilise des déclarations des seules interfaces publiques nécessaires et des fichiers de liaison générés. Aucun SDK Apple n’est redistribué. Sur Mac, le script emploie les en-têtes officiels de Xcode. Dans les deux cas, l’IPA généré doit ensuite être signé pour votre mode de distribution.

Un workflow GitHub Actions est fourni pour compiler sur un environnement macOS après dépôt des sources dans votre propre dépôt.

## Sources techniques

- [Distribution iOS — Apple](https://developer.apple.com/documentation/xcode/distributing-your-app-to-registered-devices)
- [Chargement de contenu local WKWebView — Apple](https://developer.apple.com/documentation/webkit/wkwebview/loadfileurl(_:allowingreadaccessto:))
- [Localisation — Apple](https://developer.apple.com/documentation/corelocation/cllocationmanager)
- [Géocodage — IGN](https://cartes.gouv.fr/aide/fr/guides-utilisateur/utiliser-les-services-de-la-geoplateforme/geocodage/)
- [API OSRM](https://project-osrm.org/docs/v5.24.0/api/)
- [Politique des tuiles OpenStreetMap](https://operations.osmfoundation.org/policies/tiles/)
- [Déploiement FastAPI](https://fastapi.tiangolo.com/deployment/docker/)

Leaflet 1.9.4 est distribué avec sa licence dans `web/vendor/Leaflet-LICENSE.txt`.
