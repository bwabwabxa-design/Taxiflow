# TaxiFlow 1.1 — Centrale et Chauffeur

## Les deux applications

- **TaxiFlow Centrale** : bundle `app.taxiflow.dispatch`, remplace la version 1.0.3 dans LiveContainer.
- **TaxiFlow Chauffeur** : bundle `app.taxiflow.driver`, installation séparée à côté de la centrale. Le binaire conserve les correctifs NSObject, réserve d’en-tête et liaison LLVM validés depuis 1.0.3.

Les deux fonctionnent en démonstration sans serveur. Chaque application conserve sa propre démo. Elles ne se synchronisent qu’après connexion à une même API. L’interface est intégrée dans l’IPA : une mise à jour de l’API seule ne met pas à jour les écrans d’une ancienne IPA.

## Nouveautés disponibles

- Application Chauffeur dédiée : missions, historique personnel, alertes et connexion avec un compte de rôle chauffeur. Refus explicite d’un compte administrateur dans cette édition.
- Accepter/refuser une proposition, partir vers le client, signaler l’arrivée, prendre le client à bord puis terminer. Une mission refusée revient au dispatch et libère le chauffeur.
- Carte GPS : position réelle avec consentement, précision, heure du dernier relevé, recentrage, indication de position ancienne et affichage du trajet d’une mission. Le tracé est pointillé quand l’itinéraire routier n’est pas disponible.
- Bouton « Utiliser ma position GPS » pour choisir un départ ou une arrivée. Recherche d’adresses IGN également accessible depuis la démo avec internet.
- Répétitions quotidiennes, du lundi au vendredi ou hebdomadaires, jusqu’à 60 départs dans l’année. Les départs sont créés à l’avance. Annulation des départs encore non attribués.
- Demandes clients : aperçu local en démo ; formulaire public `/booking.html` après activation du serveur. Acceptation/refus par la centrale, suivi via une clé privée. Le client ne voit aucune liste de la flotte.
- Centre de notifications dans l’application, son facultatif pendant son utilisation.
- Statistiques sur 7 jours, 30 jours ou toute la période, détail par chauffeur. Kilomètres et durées estimés, encaissements réellement enregistrés.
- Export PDF avec coordonnées et logo de l’entreprise enregistrés sur l’appareil. **Brouillon de facture**, à compléter et valider avant usage comptable ; aucune numérotation fiscale automatique.
- Paiement intégral Stripe Checkout d’une course terminée : montant final saisi, lien partageable, validation via webhook signé. Simulation sans débit en démo.
- SMS via Twilio : nouvelle mission au chauffeur ou arrivée au client, avec confirmation explicite avant chaque envoi. Aucun envoi automatique.

## Connecter la flotte plus tard

1. Déployer l’API de cette archive, démarrer la base et créer le compte administrateur avec `api/manage.py` (voir README).
2. Dans la centrale : Réglages → connexion, saisir le serveur et le compte administrateur. Ajouter les chauffeurs, puis créer un accès de rôle chauffeur pour chacun et l’associer à sa fiche.
3. Dans TaxiFlow Chauffeur : connecter la même adresse et le compte chauffeur correspondant.
4. Le chauffeur choisit sa disponibilité et active volontairement le GPS. La centrale attribue une course ; elle apparaît au prochain rafraîchissement, environ 10 secondes.

HTTP est accepté pour une adresse IPv4 privée du réseau local (10.x, 192.168.x ou 172.16 à 172.31). Les identifiants transitent alors sans chiffrement ; utiliser HTTPS pour une connexion sur internet. Le serveur doit autoriser l’origine `null` pour la WebView iOS, comme dans le compose fourni. La connexion web GPS d’un navigateur nécessite généralement HTTPS ou localhost ; l’IPA utilise le pont natif CoreLocation.

## Services facultatifs, côté serveur uniquement

Configurer `.env` et relancer `docker compose up -d --build` :

- `PUBLIC_BASE_URL` : URL HTTPS publique, sans slash final.
- `PUBLIC_BOOKING_ENABLED=1` : active les réservations publiques, désactivées par défaut. Compléter les informations de contact/confidentialité de la centrale avant ouverture et protéger le service par une limitation des requêtes au reverse proxy. La limitation intégrée est locale au processus.
- `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET` : secrets Stripe conservés uniquement sur le serveur. Déclarer le webhook `/api/v1/stripe/webhook` pour `checkout.session.completed`. Tester d’abord avec les clés Stripe de test. La page de retour n’enregistre jamais elle-même un paiement. Les paiements manuels sont bloqués tant qu’un lien Stripe est actif. Aucun acompte, remboursement ou paiement fractionné dans cette version.
- `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM` : compte et expéditeur autorisés. Téléphones au format international. Après un résultat d’envoi incertain, vérifier Twilio : pas de relance automatique pour éviter un doublon.

Les intégrations externes sont implémentées mais aucun paiement réel ni SMS réel n’a été exécuté lors des tests. Les réservations publiques restent désactivées sans configuration. Les clés ne doivent jamais être placées dans l’IPA.

## Limites à connaître

Le GPS s’arrête en arrière-plan. Aucune notification push iOS quand LiveContainer est fermé. Pas de taximètre homologué, de facture certifiée ni de kilomètres réellement parcourus. Les fonds OpenStreetMap et la recherche IGN nécessitent internet ; un fond absent n’empêche pas l’affichage des coordonnées GPS. Le serveur n’est pas hébergé par cette livraison.

## Validation

12 tests API : accès, concurrence d’attribution, transitions, paiements, répétitions idempotentes, demandes clients, confidentialité du suivi, réponses chauffeurs et webhook Stripe signé avec anti-rejeu.

Tests Chromium au format iPhone : création/attribution/acceptation/fin de course, encaissement, export, persistance, GPS simulé, arrivée, PDF, historique chauffeur, répétition et demande client. Aucun test de lancement natif de la version 1.1 sur iPhone : le lancement confirmé par l’utilisateur concernait la 1.0.3.

Compilation ARM64 iOS 15+ avec Clang et LLVM LLD ; signatures ad-hoc de préparation, contrôle des pages signées et des segments Mach-O. LiveContainer applique sa propre signature à l’importation.
