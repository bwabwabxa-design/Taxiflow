# Correction iOS 1.0.3 — crash au démarrage

Le rapport du 2 octobre à 23:34:17 montre TaxiFlow chargé et un EXC_BAD_ACCESS dans objc_release appelé depuis application:didFinishLaunchingWithOptions: (offset 38552 du binaire 1.0.2).

La déclaration minimale de NSObject dans AppleInterfaces.h omettait le champ Class isa. Le compilateur plaçait donc le premier champ fort de TFAppDelegate à l’offset zéro. Son setter appelait objc_storeStrong directement sur self, écrasant l’en-tête d’objet et tentant de libérer son ancien contenu. Cela correspond à l’emplacement du crash observé.

Correction : ajout du champ isa dans la déclaration Linux. Le setter compilé utilise maintenant self + 8. Les champs de TFController utilisent les offsets ajustables du runtime, nécessaires pour sa superclasse UIKit. La compilation Xcode utilise déjà les vrais en-têtes Apple.

Version 1.0.3, build 4. Vérifications : inspection du code assembleur des setters, compilation ARM64, alignement des segments, empreintes de signature et re-signature locale avec le cœur ZSign de LiveContainer. Le lancement réel de cette version sur iPhone reste à confirmer.

Réimporter l’IPA dans LiveContainer en remplaçant TaxiFlow si proposé, puis vérifier la version 1.0.3.

---

# Reconstruction iOS 1.0.2 — LiveContainer

La version 1.0.1 corrigeait le manque de place dans l’en-tête Mach-O : le moteur ZSign pouvait signer le fichier. Le retour sur iPhone montre que cela ne suffisait pas : LiveContainer signale ensuite une signature invalide. Le succès de ZSign seul ne permet donc pas de conclure à la compatibilité.

## Modification en 1.0.2 (build 3)

Le code Objective-C est toujours compilé avec Clang, mais la liaison Linux passe désormais par LLVM LLD 18, au lieu du linker Mach-O de Zig 0.13. Les tailles des segments __TEXT, __DATA_CONST et __DATA sont maintenant alignées sur 16 Kio. La réserve de 16 Kio dans l’en-tête et la signature ad-hoc de préparation sont conservées. Cette signature n’est pas un certificat Apple : LiveContainer doit encore appliquer le sien.

C’est une correction de structure destinée à résoudre le rejet observé, et non une résolution confirmée sur iPhone. La cause exacte du refus par le noyau iOS n’a pas pu être établie ici.

## Contrôles effectués

- Contrôle de l’alignement des segments du nouvel IPA.
- Vérification des empreintes de toutes les pages du code, d’Info.plist et du manifeste CodeResources.
- Sur une copie temporaire, conversion du type Mach-O en bibliothèque, ajout de commandes de chargement, puis re-signature par le cœur ZSign de LiveContainer : réussie.
- Pas de test des contrôles iOS F_ADDFILESIGS_RETURN/F_CHECK_LV ni du lancement sur iPhone. Ces contrôles ne sont pas disponibles sous Linux.

Réimporte le fichier en remplaçant TaxiFlow si LiveContainer le propose, puis vérifie que sa fiche affiche 1.0.2. Il n’est pas nécessaire de supprimer l’ancienne application et ses données. Si le refus persiste, le texte complet du diagnostic et les versions d’iOS et de LiveContainer seront nécessaires pour poursuivre.

## Reconstruction Linux

```sh
python3 tools/build_ipa.py --zig /chemin/zig --ld64 /chemin/ld64.lld --zsign /chemin/zsign --output dist/TaxiFlow-1.0-a-signer.ipa
python3 tools/verify_ipa.py dist/TaxiFlow-1.0-a-signer.ipa
```

Le workflow macOS fourni permet une autre reconstruction avec Xcode et son SDK officiel.

Sources techniques : [LiveContainer](https://github.com/LiveContainer/LiveContainer), [LLVM LLD Mach-O](https://lld.llvm.org/MachO/index.html).
