# Vérifications de TaxiFlow 1.0.0

Réalisées le 2 octobre 2026 dans un environnement Linux, avant livraison.

## Résultats obtenus

| Partie | Résultat |
|---|---|
| API | 8 tests automatisés réussis |
| Authentification | Connexion, session, déconnexion et limitation des échecs vérifiées |
| Droits | Un chauffeur ne peut pas lire ou modifier les courses d’un autre chauffeur, ni exporter toute la flotte |
| Attribution concurrente | Deux demandes simultanées pour le même chauffeur : une seule réussit |
| Cohérence des courses | Transitions impossibles et versions périmées refusées |
| Réservations | Attribution trop anticipée refusée ; annulation vérifiée |
| Estimation et paiement | Estimation calculée par le serveur ; montant client non accepté comme tarif ; double encaissement refusé |
| Création répétée | Clé d’idempotence évitant le doublon vérifiée |
| Export | Neutralisation des formules CSV et contrôle des droits vérifiés |
| Interface mobile | Création → attribution → approche → à bord → terminée → encaissement → export, sans erreur JavaScript |
| Interface | Recherche, fiches clients, affichage de texte hostile sans exécution HTML, ajout de chauffeur, disponibilité, persistance de la démo vérifiés |
| Responsive | Largeurs 390 et 1440 px contrôlées, sans débordement horizontal |
| API via interface | Connexion au serveur local, recherche IGN, création d’une course et actualisation réalisées avec des données fictives |
| Origine embarquée | Chargement par `file://` et connexion authentifiée à l’API vérifiés dans Chromium |
| Cartographie | Tuiles OpenStreetMap chargées ; route OSRM et recherche IGN vérifiées avec des lieux publics |
| IPA | Compilation ARM64 iOS, structure ZIP, Info.plist, dépendances et ressources embarquées vérifiées |

La vérification TLS a été désactivée uniquement dans le navigateur de test pour les services externes de cet environnement. Aucune désactivation TLS n’existe dans l’application ni dans l’API livrées.

Un avertissement de dépréciation de Starlette concerne le transport de test `httpx`. Il n’a pas entraîné d’échec.

## Ce qui reste à vérifier sur matériel Apple

L’IPA n’a pas été signé avec un certificat de distribution ou un profil personnel. Aucun appareil iOS ni simulateur Apple n’était disponible. Les vérifications suivantes ne sont donc pas revendiquées : installation, lancement effectif de l’exécutable iOS, autorisation et précision GPS, interruption du GPS en arrière-plan, clavier natif, partage iOS et rotation iPad.

Le service Docker/HTTPS est configuré, mais n’a pas été déployé sur un serveur public. Les tests ci-dessus ne constituent pas un audit de sécurité ou une qualification pour une exploitation professionnelle.

## Rejouer les tests

Depuis le dossier racine, dans un environnement Python :

```sh
python -m pip install -r requirements-dev.txt
python -m pytest api/tests -q
python -m playwright install chromium
python -m uvicorn api.main:app --host 127.0.0.1 --port 8765
# Dans un autre terminal :
python tools/test_ui.py
```

Le scénario d’interface utilise le mode démo du navigateur. Les tests API utilisent une base temporaire isolée et des comptes fictifs ; aucun mot de passe de test n’est installé dans une flotte réelle.


## Reconstruction 1.0.2

Voir CORRECTION-LIVECONTAINER.md : liaison LLVM LLD, segments alignés, empreintes vérifiées et re-signature testée localement. Acceptation iOS et lancement LiveContainer non vérifiés.


## Correction 1.0.3

Rapport iPhone du 2 octobre 23:34 analysé. Correction de la déclaration NSObject (champ isa), vérification assembleur : setWindow utilise self+8, setWeb utilise un offset runtime. Vérifications statiques IPA et re-signature locale réussies. Lancement iPhone à confirmer.


## Version 1.1 Centrale / Chauffeur

Voir VERSION-1.1.md. 12 tests API réussis et deux parcours de test navigateur réussis. Le GPS navigateur est simulé ; aucun lancement natif de cette nouvelle version n’a été testé sur iPhone.
