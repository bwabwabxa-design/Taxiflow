"""Administrative commands. Passwords are prompted, never stored in source."""
import argparse
import getpass
from .main import init_db, tx, create_user, hash_password


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['init', 'reset-password'])
    parser.add_argument('--email', required=True)
    parser.add_argument('--name', default='Administrateur')
    args = parser.parse_args()
    password = getpass.getpass('Mot de passe (12 caractères minimum) : ')
    if len(password) < 12 or password != getpass.getpass('Confirme le mot de passe : '):
        raise SystemExit('Mot de passe trop court ou confirmation différente.')
    init_db()
    with tx() as db:
        if args.command == 'init':
            create_user(db, args.email, password, args.name, 'admin')
        else:
            user = db.execute('SELECT id FROM users WHERE email=?', (args.email.lower(),)).fetchone()
            if not user:
                raise SystemExit('Compte introuvable.')
            db.execute('UPDATE users SET password=? WHERE id=?', (hash_password(password), user['id']))
            db.execute('DELETE FROM sessions WHERE user_id=?', (user['id'],))
    print('Compte prêt. Lance maintenant le serveur.')


if __name__ == '__main__':
    main()
