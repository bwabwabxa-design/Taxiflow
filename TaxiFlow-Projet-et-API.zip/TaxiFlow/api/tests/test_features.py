import hashlib,hmac,json,time
from datetime import datetime,timedelta,timezone
from test_api import api,driver,trip
from api import main as m

def test_driver_responses_and_role_isolation(api):
    c,h=api;d=driver(c,h);other=driver(c,h,'Autre chauffeur');t=trip(c,h)
    c.post('/api/v1/users',headers=h,json={'email':'driver@test.invalid','password':'driver-test-123','name':'Driver','role':'driver','driver_id':d['id']})
    login=c.post('/api/v1/auth/login',json={'email':'driver@test.invalid','password':'driver-test-123'}).json();dh={'Authorization':'Bearer '+login['token']}
    assert c.get('/api/v1/bookings',headers=dh).status_code==403
    assigned=c.post('/api/v1/trips/'+t['id']+'/assign',headers=h,json={'driver_id':other['id'],'version':1}).json()
    assert c.post('/api/v1/trips/'+t['id']+'/response',headers=dh,json={'action':'accept','version':assigned['version']}).status_code==403
    assert c.get('/api/v1/state',headers=dh).json()['trips']==[]
    r=c.post('/api/v1/trips/'+t['id']+'/response',headers=h,json={'action':'refuse','version':assigned['version']});assert r.status_code==200
    t=r.json();assert t['driver_id'] is None and t['status']=='pending'
    t=c.post('/api/v1/trips/'+t['id']+'/assign',headers=h,json={'driver_id':d['id'],'version':t['version']}).json()
    t=c.post('/api/v1/trips/'+t['id']+'/response',headers=dh,json={'action':'accept','version':t['version']}).json();assert t['accepted_at']
    t=c.post('/api/v1/trips/'+t['id']+'/status',headers=dh,json={'status':'en_route','version':t['version']}).json()
    t=c.post('/api/v1/trips/'+t['id']+'/response',headers=dh,json={'action':'arrive','version':t['version']}).json();assert t['arrived_at']

def test_series_idempotent_and_cancel(api):
    c,h=api;t=trip(c,h);dates=[(datetime.now(timezone.utc)+timedelta(days=n)).isoformat() for n in (1,2,3)]
    body={'trip':t,'dates':dates};headers={**h,'Idempotency-Key':'series-test'}
    a=c.post('/api/v1/series',headers=headers,json=body);assert a.status_code==200,a.text
    b=c.post('/api/v1/series',headers=headers,json=body);assert b.json()==a.json()
    assert c.post('/api/v1/series/'+a.json()['id']+'/cancel',headers=h).json()['count']==3

def test_public_booking_tracking_and_accept(api,monkeypatch):
    c,h=api;t=trip(c,h)
    assert c.post('/api/v1/public/bookings',json={'trip':t,'consent':True}).status_code==503
    monkeypatch.setenv('PUBLIC_BOOKING_ENABLED','1')
    r=c.post('/api/v1/public/bookings',json={'trip':t,'consent':True});assert r.status_code==200,r.text
    b=r.json();track={'reference':b['reference'],'token':b['token']}
    assert c.post('/api/v1/public/track',json={**track,'token':'x'*40}).status_code==404
    r=c.post('/api/v1/bookings/'+b['reference']+'/decision',headers=h,json={'accept':True});assert r.status_code==200
    assert 'tracking_hash' not in r.json()
    tracked=c.post('/api/v1/public/track',json=track).json();assert tracked['status']=='pending';assert 'trip' not in tracked and 'phone' not in tracked

def test_stripe_signature_amount_and_replay(api,monkeypatch):
    c,h=api;t=trip(c,h);monkeypatch.setenv('STRIPE_WEBHOOK_SECRET','test-secret')
    with m.tx() as db:
        t.update(status='completed',checkout_attempt='attempt',checkout_amount=2300);m.put(db,'trips',t)
    event={'id':'evt_test','type':'checkout.session.completed','data':{'object':{'payment_status':'paid','currency':'eur','amount_total':2300,'metadata':{'trip_id':t['id'],'attempt':'attempt'}}}}
    raw=json.dumps(event).encode();ts=str(int(time.time()));sig=hmac.new(b'test-secret',ts.encode()+b'.'+raw,hashlib.sha256).hexdigest()
    assert c.post('/api/v1/stripe/webhook',content=raw).status_code==400
    for _ in range(2):assert c.post('/api/v1/stripe/webhook',content=raw,headers={'Stripe-Signature':f't={ts},v1={sig}'}).status_code==200
    result=next(x for x in c.get('/api/v1/state',headers=h).json()['trips'] if x['id']==t['id']);assert result['paid_cents']==2300 and result['version']==2
