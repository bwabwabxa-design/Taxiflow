from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
import sqlite3

import pytest
from fastapi.testclient import TestClient
from api import main as m


@pytest.fixture
def api(tmp_path, monkeypatch):
    monkeypatch.setattr(m, 'DB_PATH', str(tmp_path/'test.sqlite3'))
    m.login_attempts.clear()
    async def route(p, d):
        return {'distance_km': 10, 'duration_min': 20, 'geometry': None, 'source': 'test', 'approximate': False}
    monkeypatch.setattr(m, 'route_info', route)
    with TestClient(m.app) as client:
        with m.tx() as db:
            m.create_user(db, 'admin@test.invalid', 'test-password-123', 'Test Admin', 'admin')
        login=client.post('/api/v1/auth/login',json={'email':'admin@test.invalid','password':'test-password-123'})
        auth={'Authorization':'Bearer '+login.json()['token']}
        yield client,auth


def driver(c,h,name='Chauffeur test',category='standard',seats=4):
    r=c.post('/api/v1/drivers',headers=h,json={'name':name,'callsign':'TEST','vehicle':'Voiture','category':category,'seats':seats})
    assert r.status_code==201,r.text
    d=r.json()
    assert c.patch('/api/v1/drivers/'+d['id']+'/status',headers=h,json={'status':'available'}).status_code==200
    assert c.put('/api/v1/drivers/'+d['id']+'/location',headers=h,json={'lat':48.86,'lon':2.34,'accuracy':10}).status_code==200
    return d


def trip(c,h,**extra):
    data={'pickup':{'label':'Départ test','lat':48.85,'lon':2.35},'destination':{'label':'Arrivée test','lat':48.75,'lon':2.36},'passenger':'Test Client',**extra}
    r=c.post('/api/v1/trips',headers=h,json=data)
    assert r.status_code==201,r.text
    return r.json()


def test_auth_no_data_without_token_and_logout(api):
    c,h=api
    assert c.get('/api/v1/state').status_code==401
    assert c.post('/api/v1/auth/login',json={'email':'admin@test.invalid','password':'incorrect'}).status_code==401
    assert c.get('/api/v1/state',headers=h).status_code==200
    assert c.post('/api/v1/auth/logout',headers=h).status_code==204
    assert c.get('/api/v1/state',headers=h).status_code==401


def test_complete_lifecycle_and_payment_is_recorded_once(api):
    c,h=api;d=driver(c,h);t=trip(c,h,fare_cents=1)
    assert t['fare_cents']==2800  # Server recalculates price; client cannot override it.
    r=c.post(f"/api/v1/trips/{t['id']}/status",headers=h,json={'status':'completed','version':1})
    assert r.status_code==409
    t=c.post(f"/api/v1/trips/{t['id']}/assign",headers=h,json={'version':1}).json()
    assert t['driver_id']==d['id']
    assert c.patch('/api/v1/drivers/'+d['id']+'/status',headers=h,json={'status':'available'}).status_code==409
    assert c.post(f"/api/v1/trips/{t['id']}/status",headers=h,json={'status':'en_route','version':1}).status_code==409
    for status in ['en_route','on_board','completed']:
        r=c.post(f"/api/v1/trips/{t['id']}/status",headers=h,json={'status':status,'version':t['version']})
        assert r.status_code==200,r.text
        t=r.json()
    r=c.post(f"/api/v1/trips/{t['id']}/payment",headers=h,json={'amount_cents':3250,'method':'card','version':t['version']})
    assert r.status_code==200
    paid=r.json();assert paid['paid_cents']==3250
    assert c.post(f"/api/v1/trips/{t['id']}/payment",headers=h,json={'amount_cents':3250,'method':'card','version':paid['version']}).status_code==409
    state=c.get('/api/v1/state',headers=h).json()
    assert state['drivers'][0]['status']=='available'
    assert len(c.get('/api/v1/audit',headers=h).json())>=7


def test_concurrent_assignments_cannot_double_book(api):
    c,h=api;d=driver(c,h);ts=[trip(c,h),trip(c,h)]
    def assign(t):return c.post(f"/api/v1/trips/{t['id']}/assign",headers=h,json={'driver_id':d['id'],'version':1}).status_code
    with ThreadPoolExecutor(max_workers=2) as pool:
        codes=list(pool.map(assign,ts))
    assert sorted(codes)==[200,409]
    active=[t for t in c.get('/api/v1/state',headers=h).json()['trips'] if t['status']=='assigned']
    assert len(active)==1


def test_category_capacity_and_old_gps_are_enforced(api):
    c,h=api;d=driver(c,h);t=trip(c,h,category='van',passengers=6)
    assert c.post(f"/api/v1/trips/{t['id']}/assign",headers=h,json={'driver_id':d['id'],'version':1}).status_code==409
    van=driver(c,h,'Van test','van',7)
    with m.tx() as db:
        data=m.get(db,'drivers',van['id']);data['location_updated_at']=(datetime.now(timezone.utc)-timedelta(hours=1)).isoformat();m.put(db,'drivers',data)
    assert c.post(f"/api/v1/trips/{t['id']}/assign",headers=h,json={'version':1}).status_code==409
    assert c.post(f"/api/v1/trips/{t['id']}/assign",headers=h,json={'driver_id':van['id'],'version':1}).status_code==200


def test_driver_cannot_read_or_change_another_driver_data(api):
    c,h=api;d=driver(c,h);other=driver(c,h,'Autre chauffeur');t=trip(c,h);other_t=trip(c,h)
    c.post(f"/api/v1/trips/{t['id']}/assign",headers=h,json={'driver_id':d['id'],'version':1})
    c.post(f"/api/v1/trips/{other_t['id']}/assign",headers=h,json={'driver_id':other['id'],'version':1})
    r=c.post('/api/v1/users',headers=h,json={'name':'Compte Chauffeur','email':'driver@test.invalid','password':'another-password-123','role':'driver','driver_id':d['id']})
    assert r.status_code==201
    token=c.post('/api/v1/auth/login',json={'email':'driver@test.invalid','password':'another-password-123'}).json()['token']
    dh={'Authorization':'Bearer '+token}
    state=c.get('/api/v1/state',headers=dh).json()
    assert [x['id'] for x in state['trips']]==[t['id']]
    assert [x['id'] for x in state['drivers']]==[d['id']]
    assert state['customers']==[]
    assert c.get('/api/v1/export.csv',headers=dh).status_code==403
    assert c.post('/api/v1/customers',headers=dh,json={'name':'Interdit'}).status_code==403
    assert c.put('/api/v1/drivers/'+other['id']+'/location',headers=dh,json={'lat':0,'lon':0,'accuracy':1}).status_code==403
    assert c.post(f"/api/v1/trips/{other_t['id']}/status",headers=dh,json={'status':'en_route','version':2}).status_code==403
    assert c.post(f"/api/v1/trips/{t['id']}/status",headers=dh,json={'status':'cancelled','version':2}).status_code==403
    assert c.post(f"/api/v1/trips/{t['id']}/status",headers=dh,json={'status':'en_route','version':2}).status_code==200


def test_booking_window_validation_and_cancellation(api):
    c,h=api;driver(c,h)
    t=trip(c,h,scheduled_at=(datetime.now(timezone.utc)+timedelta(hours=2)).isoformat())
    assert t['status']=='scheduled'
    assert c.post(f"/api/v1/trips/{t['id']}/assign",headers=h,json={'version':1}).status_code==409
    assert c.post(f"/api/v1/trips/{t['id']}/status",headers=h,json={'status':'cancelled','version':1}).status_code==200
    bad={'pickup':{'label':'test','lat':91,'lon':2},'destination':{'label':'test','lat':48,'lon':2},'passenger':'Test'}
    assert c.post('/api/v1/trips',headers=h,json=bad).status_code==422
    assert c.post('/api/v1/drivers',headers=h,json={'name':'Test','callsign':'X','vehicle':'Car','seats':0}).status_code==422


def test_idempotent_creation_and_csv_formula_injection(api):
    c,h=api
    payload={'pickup':{'label':'Départ','lat':48,'lon':2},'destination':{'label':'Arrivée','lat':49,'lon':2},'passenger':'=HYPERLINK("malicious")'}
    headers={**h,'Idempotency-Key':'same-request'}
    a=c.post('/api/v1/trips',headers=headers,json=payload)
    b=c.post('/api/v1/trips',headers=headers,json=payload)
    assert a.json()['id']==b.json()['id']
    payload['passenger']='Different'
    assert c.post('/api/v1/trips',headers=headers,json=payload).status_code==409
    export=c.get('/api/v1/export.csv',headers=h).text
    assert "'=HYPERLINK" in export
    assert len(c.get('/api/v1/state',headers=h).json()['trips'])==1


def test_rate_limit_and_cors(api):
    c,h=api
    for _ in range(10):
        assert c.post('/api/v1/auth/login',json={'email':'nobody@test.invalid','password':'wrong'}).status_code==401
    assert c.post('/api/v1/auth/login',json={'email':'nobody@test.invalid','password':'wrong'}).status_code==429
    res=c.options('/api/v1/state',headers={'Origin':'null','Access-Control-Request-Method':'GET','Access-Control-Request-Headers':'authorization'})
    assert res.status_code==200
    assert res.headers['access-control-allow-origin']=='null'
    res=c.options('/api/v1/state',headers={'Origin':'https://malicious.invalid','Access-Control-Request-Method':'GET'})
    assert res.status_code==400
