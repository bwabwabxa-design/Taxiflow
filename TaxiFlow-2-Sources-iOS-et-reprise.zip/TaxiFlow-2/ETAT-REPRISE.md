# TaxiFlow 2 — état de reprise du 4 octobre 2026

Cette archive contient les sources iOS préparées et compilées, pas une application complète prête à utiliser. Aucun nouveau site n'a été publié et les anciens services sont conservés.

## Projet web/API Lovable

Projet : https://lovable.dev/projects/d2fd0614-ad7c-4bd4-b65b-731d6b515686

Commit actuel : `261bef017c4509544badbfd7450b6a0a5c568c25`.

La base PostgreSQL Lovable Cloud est activée. Les tables `rides`, `drivers`, `user_roles`, `tariff_settings`, `audit_log`, `rate_events` ont été constatées via une requête SQL. Lovable a créé les RPC de dispatch et de chauffeur ainsi que du code de réservation publique, géocodage IGN, estimation OSRM, suivi privé, authentification et pont GPS iOS.

Ce code web n'est pas encore validé : les dépendances et types produisent des erreurs de compilation et les pages réservation, centrale, chauffeur et suivi restent à terminer. Aucun parcours de réservation de bout en bout n'a été testé. Le quota de crédits Lovable a ensuite bloqué la continuation. L'API ne doit pas être annoncée comme opérationnelle.

Les sources web/API sont conservées dans le projet Lovable ci-dessus. Aucune clé privée n'est intégrée à cette archive.

## Sources iOS

Deux éditions ARM64 iOS 15+ : `app.taxiflow.dispatch` et `app.taxiflow.driver`. Version prévue 2.0.0, build 20. Chaque édition ouvre respectivement `/centrale` ou `/chauffeur` sur le futur domaine publié. La compilation exige explicitement ce domaine HTTPS.

Fonctions natives : WKWebView, session web persistante, GPS au premier plan sur demande, arrêt en arrière-plan, filtrage des positions datant de plus de 30 secondes, pont limité au domaine HTTPS configuré et à la fenêtre principale, appels téléphone et navigation externes, écran local de reconnexion en cas d'échec. Pas de serveur historique codé en dur ni de clé administrateur.

La correction d'en-tête `NSObject` avec `Class isa` est conservée : elle évite la corruption d'objets observée dans un ancien IPA.

Vérifications exécutées : compilation native ARM64, liaison LLVM LLD 18, signature ad hoc zsign, alignement des segments sur 16 Ko, empreintes des pages Mach-O, de l'Info.plist et des ressources. Le lancement dans LiveContainer ou sur un iPhone réel n'a pas été testé.

## Construction après publication du web

Outils utilisés lors du contrôle : Python 3 avec Pillow, Zig 0.13.0, LLVM LLD 18.1.3, zsign 1.1.2 (commit officiel `614caa8d1ca949e260e5746144aa52d27a4b08d6`). macOS peut utiliser Xcode et le SDK public à la place de Zig/LLD.

```bash
python native/tools/build_ipa.py --edition dispatch --site-url https://DOMAINE-PUBLIE --zig /chemin/zig --ld64 /chemin/ld64.lld --zsign /chemin/zsign --output TaxiFlow-Centrale-2.0.0.ipa
python native/tools/build_ipa.py --edition driver --site-url https://DOMAINE-PUBLIE --zig /chemin/zig --ld64 /chemin/ld64.lld --zsign /chemin/zsign --output TaxiFlow-Chauffeur-2.0.0.ipa
python native/tools/verify_ipa.py TaxiFlow-Centrale-2.0.0.ipa
python native/tools/verify_ipa.py TaxiFlow-Chauffeur-2.0.0.ipa
```

Les IPA sont signées ad hoc pour re-signature par l'outil d'installation. Cette signature n'est pas une signature Apple de distribution. Confirmer le fonctionnement dans LiveContainer avant de déclarer la version utilisable.

## Suite requise

1. Rétablir les crédits du workspace Lovable pour poursuivre selon le choix de l'utilisateur.
2. Corriger la compilation web, terminer les pages et tester le parcours réservation → centrale → chauffeur → suivi.
3. Vérifier les droits et RPC : accès d'un chauffeur limité à ses courses, rôle admin non auto-attribué, affectation concurrente refusée, idempotence des réservations, suivi privé, validation des coordonnées et montants.
4. Créer le compte propriétaire par le vrai formulaire, vérifier l'adresse puis promouvoir explicitement ce compte via SQL privilégié. Ne jamais promouvoir automatiquement le premier inscrit ni utiliser un mot de passe public.
5. Publier seulement après vérifications, relever le vrai domaine, compiler les deux IPA sur ce domaine et vérifier les archives.
6. Tester le lancement sur l'iPhone de l'utilisateur et la géolocalisation avec consentement.

Les comptes et données de l'ancien Render n'ont pas été migrés. La nouvelle version ne doit pas remplacer les anciens services sans avoir été validée.
