"""TaxiFlow — single-fleet API. Start with: python -m uvicorn api.main:app."""
import csv
import hashlib
import hmac
import io
import json
import math
import os
import secrets
import sqlite3
import time
import uuid
from collections import defaultdict, deque
from contextlib import contextmanager, asynccontextmanager, closing
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

import httpx
from fastapi import FastAPI, Depends, HTTPException, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import PlainTextResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator

DB_PATH = os.getenv('TAXIFLOW_DB', str(Path(__file__).parent / 'data' / 'taxiflow.sqlite3'))
ACTIVE = {'assigned', 'en_route', 'on_board'}
ROLES = {'admin', 'dispatcher'}
TRANSITIONS = {'pending': {'cancelled'}, 'scheduled': {'cancelled'},
               'assigned': {'en_route', 'cancelled'}, 'en_route': {'on_board', 'cancelled'},
               'on_board': {'completed'}, 'completed': set(), 'cancelled': set()}
DEFAULT_SETTINGS = {'company': 'TaxiFlow', 'currency': 'EUR', 'base': 3.0,
                    'per_km': 1.8, 'per_minute': 0.35, 'minimum': 8.0, 'van_extra': 10.0}
login_attempts = defaultdict(deque)


def now():
    return datetime.now(timezone.utc).isoformat()


def stamp(value):
    return datetime.fromisoformat(value.replace('Z', '+00:00')).timestamp()


def uid(prefix):
    return prefix + '_' + uuid.uuid4().hex[:12]


def connection():
    Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DB_PATH, timeout=15, isolation_level=None)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    return db


def init_db():
    with closing(connection()) as db:
        db.execute('PRAGMA journal_mode=WAL')
        db.executescript('''
        CREATE TABLE IF NOT EXISTS series(id TEXT PRIMARY KEY, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS bookings(id TEXT PRIMARY KEY, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS stripe_events(id TEXT PRIMARY KEY);
        CREATE TABLE IF NOT EXISTS sms_sent(id TEXT PRIMARY KEY);
        CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, email TEXT UNIQUE NOT NULL,
          password TEXT NOT NULL, role TEXT NOT NULL, driver_id TEXT, name TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL
          REFERENCES users(id) ON DELETE CASCADE, expires REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS drivers(id TEXT PRIMARY KEY, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS customers(id TEXT PRIMARY KEY, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS trips(id TEXT PRIMARY KEY, driver_id TEXT REFERENCES drivers(id),
          status TEXT NOT NULL, data TEXT NOT NULL);
        CREATE UNIQUE INDEX IF NOT EXISTS one_active_trip_per_driver ON trips(driver_id)
          WHERE driver_id IS NOT NULL AND status IN ('assigned','en_route','on_board');
        CREATE TABLE IF NOT EXISTS settings(id INTEGER PRIMARY KEY CHECK(id=1), data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL,
          actor TEXT NOT NULL, action TEXT NOT NULL, target TEXT NOT NULL, detail TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS idempotency(user_id TEXT NOT NULL, key TEXT NOT NULL,
          payload_hash TEXT NOT NULL, trip_id TEXT NOT NULL, PRIMARY KEY(user_id,key));
        ''')
        db.execute('INSERT OR IGNORE INTO settings VALUES(1,?)', (json.dumps(DEFAULT_SETTINGS),))


@contextmanager
def tx():
    db = connection()
    try:
        db.execute('BEGIN IMMEDIATE')
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def get(db, table, ident):
    row = db.execute(f'SELECT data FROM {table} WHERE id=?', (ident,)).fetchone()
    if not row:
        raise HTTPException(404, 'Élément introuvable.')
    return json.loads(row['data'])


def rows(db, table):
    return [json.loads(r['data']) for r in db.execute(f'SELECT data FROM {table}')]


def put(db, table, obj):
    if table == 'trips':
        db.execute('INSERT INTO trips VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET '
                   'driver_id=excluded.driver_id,status=excluded.status,data=excluded.data',
                   (obj['id'], obj.get('driver_id'), obj['status'], json.dumps(obj)))
    else:
        db.execute(f'INSERT INTO {table} VALUES(?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data',
                   (obj['id'], json.dumps(obj)))


def audit(db, user, action, target, detail=''):
    db.execute('INSERT INTO audit(at,actor,action,target,detail) VALUES(?,?,?,?,?)',
               (now(), user['id'], action, target, detail))


def hash_password(password, salt=None):
    salt = salt or secrets.token_hex(16)
    digest = hashlib.scrypt(password.encode(), salt=salt.encode(), n=16384, r=8, p=1).hex()
    return salt + ':' + digest


def create_user(db, email, password, name, role='dispatcher', driver_id=None):
    if len(password) < 12:
        raise ValueError('Le mot de passe doit contenir au moins 12 caractères.')
    ident = uid('usr')
    db.execute('INSERT INTO users VALUES(?,?,?,?,?,?)',
               (ident, email.strip().lower(), hash_password(password), role, driver_id, name))
    return ident


def bootstrap_admin_from_env():
    """Create the first admin from Render/server environment variables.

    Nothing happens unless TAXIFLOW_ADMIN_EMAIL and TAXIFLOW_ADMIN_PASSWORD are set.
    Existing accounts are never overwritten.
    """
    email = os.getenv('TAXIFLOW_ADMIN_EMAIL', '').strip().lower()
    password = os.getenv('TAXIFLOW_ADMIN_PASSWORD', '')
    name = os.getenv('TAXIFLOW_ADMIN_NAME', 'Administrateur').strip() or 'Administrateur'
    if not email and not password:
        return
    if not email or not password:
        raise RuntimeError('TAXIFLOW_ADMIN_EMAIL et TAXIFLOW_ADMIN_PASSWORD doivent être définis ensemble.')
    if len(password) < 12:
        raise RuntimeError('TAXIFLOW_ADMIN_PASSWORD doit contenir au moins 12 caractères.')
    with tx() as db:
        row = db.execute('SELECT role FROM users WHERE email=?', (email,)).fetchone()
        if row:
            if row['role'] != 'admin':
                raise RuntimeError('TAXIFLOW_ADMIN_EMAIL existe déjà avec un autre rôle.')
            return
        create_user(db, email, password, name, 'admin')



def current_user(request: Request):
    token = request.headers.get('Authorization', '')
    if not token.startswith('Bearer '):
        raise HTTPException(401, 'Connecte-toi pour accéder à la flotte.')
    with closing(connection()) as db:
        row = db.execute('SELECT u.* FROM users u JOIN sessions s ON u.id=s.user_id '
                         'WHERE s.token_hash=? AND s.expires>?',
                         (hashlib.sha256(token[7:].encode()).hexdigest(), time.time())).fetchone()
    if not row:
        raise HTTPException(401, 'Session expirée. Reconnecte-toi.')
    return {k: row[k] for k in ('id', 'email', 'name', 'role', 'driver_id')}


def dispatcher(user=Depends(current_user)):
    if user['role'] not in ROLES:
        raise HTTPException(403, 'Accès réservé au dispatch.')
    return user


@asynccontextmanager
async def lifespan(app):
    init_db()
    bootstrap_admin_from_env()
    yield


app = FastAPI(title='TaxiFlow API', version='1.1.0', description='API privée de gestion d’une flotte de taxis.', lifespan=lifespan)
# Bearer authentication only; native bundled WKWebView has an opaque (null) origin.
app.add_middleware(CORSMiddleware, allow_origins=os.getenv('CORS_ORIGINS', 'null,http://localhost:8000,http://127.0.0.1:8000').split(','),
                   allow_credentials=False, allow_methods=['GET', 'POST', 'PATCH', 'PUT'],
                   allow_headers=['Authorization', 'Content-Type', 'Idempotency-Key'])


@app.middleware('http')
async def security_headers(request, call_next):
    response = await call_next(request)
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    if request.url.path.startswith('/api/'):
        response.headers['Cache-Control'] = 'no-store'
    return response


class Login(BaseModel):
    email: str = Field(min_length=3, max_length=254)
    password: str = Field(min_length=1, max_length=256)


@app.post('/api/v1/auth/login')
def login(body: Login, request: Request):
    key = (request.client.host if request.client else '', body.email.lower())
    attempts = login_attempts[key]
    while attempts and attempts[0] < time.time() - 900:
        attempts.popleft()
    if len(attempts) >= 10:
        raise HTTPException(429, 'Trop de tentatives. Réessaie dans 15 minutes.')
    attempts.append(time.time())
    with tx() as db:
        row = db.execute('SELECT * FROM users WHERE email=?', (body.email.strip().lower(),)).fetchone()
        stored = row['password'] if row else hash_password('dummy-not-a-valid-password', '0' * 32)
        if not hmac.compare_digest(hash_password(body.password, stored.split(':')[0]), stored) or not row:
            raise HTTPException(401, 'Identifiants incorrects.')
        token = secrets.token_urlsafe(40)
        db.execute('DELETE FROM sessions WHERE expires<?', (time.time(),))
        db.execute('INSERT INTO sessions VALUES(?,?,?)',
                   (hashlib.sha256(token.encode()).hexdigest(), row['id'], time.time() + 12 * 3600))
        attempts.clear()
        return {'token': token, 'expires_in': 43200,
                'user': {k: row[k] for k in ('id', 'name', 'email', 'role', 'driver_id')}}


@app.post('/api/v1/auth/logout', status_code=204)
def logout(request: Request, user=Depends(current_user)):
    with tx() as db:
        db.execute('DELETE FROM sessions WHERE token_hash=?',
                   (hashlib.sha256(request.headers['Authorization'][7:].encode()).hexdigest(),))
    return Response(status_code=204)


@app.get('/api/v1/health')
def health():
    return {'status': 'ok', 'version': '1.0.0'}


@app.get('/api/v1/state')
def state(user=Depends(current_user)):
    with closing(connection()) as db:
        trips, drivers, customers = rows(db, 'trips'), rows(db, 'drivers'), rows(db, 'customers')
        settings = json.loads(db.execute('SELECT data FROM settings WHERE id=1').fetchone()[0])
        if user['role'] == 'driver':
            trips = [t for t in trips if t.get('driver_id') == user['driver_id']]
            drivers = [d for d in drivers if d['id'] == user['driver_id']]
            customers = []
        return {'trips': trips, 'drivers': drivers, 'customers': customers,
                'settings': settings, 'user': user, 'server_time': now()}


class Point(BaseModel):
    label: str = Field(min_length=2, max_length=300)
    lat: float = Field(ge=-90, le=90)
    lon: float = Field(ge=-180, le=180)


class RouteRequest(BaseModel):
    pickup: Point
    destination: Point


def distance(a, b):
    x1, x2 = math.radians(a['lat']), math.radians(b['lat'])
    dx = x2 - x1
    dy = math.radians(b['lon'] - a['lon'])
    return 6371 * 2 * math.asin(min(1, math.sqrt(math.sin(dx / 2)**2 + math.cos(x1) * math.cos(x2) * math.sin(dy / 2)**2)))


async def route_info(pickup, destination):
    # Administrator-specified backend URL; never supplied by a client request.
    base = os.getenv('OSRM_URL', 'https://router.project-osrm.org').rstrip('/')
    coords = f"{pickup['lon']},{pickup['lat']};{destination['lon']},{destination['lat']}"
    try:
        async with httpx.AsyncClient(timeout=7) as client:
            res = await client.get(base + '/route/v1/driving/' + coords,
                                   params={'overview': 'simplified', 'geometries': 'geojson'},
                                   headers={'User-Agent': 'TaxiFlow/1.0'})
            res.raise_for_status()
            r = res.json()['routes'][0]
            return {'distance_km': round(r['distance'] / 1000, 2), 'duration_min': round(r['duration'] / 60, 1),
                    'geometry': r['geometry'], 'source': 'osrm', 'approximate': False}
    except (httpx.HTTPError, ValueError, KeyError, IndexError):
        km = distance(pickup, destination) * 1.35
        return {'distance_km': round(km, 2), 'duration_min': round(km / 25 * 60, 1),
                'geometry': None, 'source': 'approximation', 'approximate': True}


def fare(settings, route, category):
    value = settings['base'] + route['distance_km'] * settings['per_km'] + route['duration_min'] * settings['per_minute']
    if category == 'van':
        value += settings['van_extra']
    return round(max(settings['minimum'], value) * 100)


@app.get('/api/v1/geocode')
async def geocode(q: str, user=Depends(current_user)):
    if not 3 <= len(q) <= 200:
        raise HTTPException(422, 'Saisis une adresse de 3 à 200 caractères.')
    try:
        async with httpx.AsyncClient(timeout=8) as client:
            res = await client.get('https://data.geopf.fr/geocodage/search', params={'q': q, 'limit': 5},
                                   headers={'User-Agent': 'TaxiFlow/1.0'})
            res.raise_for_status()
            return [{'label': f['properties']['label'], 'lon': f['geometry']['coordinates'][0],
                     'lat': f['geometry']['coordinates'][1]} for f in res.json()['features']]
    except (httpx.HTTPError, ValueError, KeyError):
        raise HTTPException(503, 'La recherche d’adresse est indisponible. Réessaie plus tard.')


@app.post('/api/v1/route')
async def route(body: RouteRequest, user=Depends(current_user)):
    return await route_info(body.pickup.model_dump(), body.destination.model_dump())


class QuoteRequest(RouteRequest):
    category: Literal['standard', 'van', 'pmr'] = 'standard'


@app.post('/api/v1/quote')
async def quote(body: QuoteRequest, user=Depends(dispatcher)):
    r = await route_info(body.pickup.model_dump(), body.destination.model_dump())
    with closing(connection()) as db:
        settings = json.loads(db.execute('SELECT data FROM settings WHERE id=1').fetchone()[0])
    return {**r, 'fare_cents': fare(settings, r, body.category), 'currency': 'EUR', 'is_estimate': True}


class DriverInput(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    phone: str = Field(default='', max_length=30)
    callsign: str = Field(min_length=1, max_length=20)
    vehicle: str = Field(min_length=1, max_length=100)
    plate: str = Field(default='', max_length=20)
    category: Literal['standard', 'van', 'pmr'] = 'standard'
    seats: int = Field(default=4, ge=1, le=9)
    notes: str = Field(default='', max_length=2000)


@app.post('/api/v1/drivers', status_code=201)
def add_driver(body: DriverInput, user=Depends(dispatcher)):
    d = {**body.model_dump(), 'id': uid('drv'), 'status': 'offline', 'lat': None, 'lon': None, 'location_updated_at': None}
    with tx() as db:
        put(db, 'drivers', d)
        audit(db, user, 'driver.created', d['id'])
    return d


class DriverStatus(BaseModel):
    status: Literal['available', 'break', 'offline']


def own_driver(user, ident):
    if user['role'] == 'driver' and user['driver_id'] != ident:
        raise HTTPException(403, 'Ce chauffeur ne correspond pas à ton compte.')


@app.patch('/api/v1/drivers/{ident}/status')
def driver_status(ident: str, body: DriverStatus, user=Depends(current_user)):
    own_driver(user, ident)
    with tx() as db:
        d = get(db, 'drivers', ident)
        if any(t.get('driver_id') == ident and t['status'] in ACTIVE for t in rows(db, 'trips')):
            raise HTTPException(409, 'Termine ou annule la course en cours avant de changer de disponibilité.')
        d['status'] = body.status
        put(db, 'drivers', d)
        audit(db, user, 'driver.status', ident, body.status)
        return d


class Location(BaseModel):
    lat: float = Field(ge=-90, le=90)
    lon: float = Field(ge=-180, le=180)
    accuracy: float = Field(ge=0, le=100000)


@app.put('/api/v1/drivers/{ident}/location')
def location(ident: str, body: Location, user=Depends(current_user)):
    own_driver(user, ident)
    with tx() as db:
        d = get(db, 'drivers', ident)
        d.update({**body.model_dump(), 'location_updated_at': now(), 'location_source': 'device'})
        put(db, 'drivers', d)
    return {'ok': True}


class UserInput(BaseModel):
    email: str = Field(min_length=3, max_length=254)
    password: str = Field(min_length=12, max_length=256)
    name: str = Field(min_length=2, max_length=100)
    role: Literal['dispatcher', 'driver']
    driver_id: str | None = None


@app.post('/api/v1/users', status_code=201)
def add_user(body: UserInput, user=Depends(current_user)):
    if user['role'] != 'admin':
        raise HTTPException(403, 'Seul un administrateur peut créer des comptes.')
    with tx() as db:
        if body.role == 'driver':
            get(db, 'drivers', body.driver_id or '')
        try:
            ident = create_user(db, body.email, body.password, body.name, body.role, body.driver_id if body.role == 'driver' else None)
        except sqlite3.IntegrityError:
            raise HTTPException(409, 'Cette adresse est déjà utilisée.')
        audit(db, user, 'user.created', ident, body.role)
    return {'id': ident}


class CustomerInput(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    phone: str = Field(default='', max_length=30)
    notes: str = Field(default='', max_length=2000)


@app.post('/api/v1/customers', status_code=201)
def customer(body: CustomerInput, user=Depends(dispatcher)):
    obj = {**body.model_dump(), 'id': uid('cli'), 'created_at': now()}
    with tx() as db:
        put(db, 'customers', obj)
        audit(db, user, 'customer.created', obj['id'])
    return obj


class TripInput(QuoteRequest):
    passenger: str = Field(min_length=2, max_length=100)
    phone: str = Field(default='', max_length=30)
    passengers: int = Field(default=1, ge=1, le=9)
    bags: int = Field(default=0, ge=0, le=15)
    priority: Literal['normal', 'urgent'] = 'normal'
    scheduled_at: datetime | None = None
    payment_method: Literal['cash', 'card', 'account'] = 'card'
    notes: str = Field(default='', max_length=2000)
    customer_id: str | None = None

    @field_validator('scheduled_at')
    @classmethod
    def future_time(cls, value):
        if value is not None and (value.tzinfo is None or value.timestamp() < time.time() - 60):
            raise ValueError('La réservation doit être dans le futur, avec un fuseau horaire.')
        return value


@app.post('/api/v1/trips', status_code=201)
async def add_trip(body: TripInput, request: Request, user=Depends(dispatcher)):
    data = body.model_dump(mode='json')
    payload_hash = hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()
    key = request.headers.get('Idempotency-Key', '')[:128]
    r = await route_info(data['pickup'], data['destination'])
    with tx() as db:
        if key:
            old = db.execute('SELECT * FROM idempotency WHERE user_id=? AND key=?', (user['id'], key)).fetchone()
            if old:
                if old['payload_hash'] != payload_hash:
                    raise HTTPException(409, 'Cette clé de création appartient déjà à une autre demande.')
                return get(db, 'trips', old['trip_id'])
        if data['customer_id']:
            get(db, 'customers', data['customer_id'])
        settings = json.loads(db.execute('SELECT data FROM settings WHERE id=1').fetchone()[0])
        trip = {**data, **r, 'id': uid('trp'), 'driver_id': None,
                'fare_cents': fare(settings, r, body.category), 'payment_status': 'unpaid',
                'status': 'scheduled' if body.scheduled_at else 'pending',
                'version': 1, 'created_at': now(), 'updated_at': now()}
        put(db, 'trips', trip)
        if key:
            db.execute('INSERT INTO idempotency VALUES(?,?,?,?)', (user['id'], key, payload_hash, trip['id']))
        audit(db, user, 'trip.created', trip['id'])
    return trip


class Assignment(BaseModel):
    driver_id: str | None = None
    version: int = Field(ge=1)


def fresh(d):
    return d.get('lat') is not None and d.get('lon') is not None and d.get('location_updated_at') and time.time() - stamp(d['location_updated_at']) <= 300


def compatible(d, t):
    return d['status'] == 'available' and d['seats'] >= t['passengers'] and (t['category'] == 'standard' or d['category'] == t['category'])


def version_check(trip, version):
    if trip['version'] != version:
        raise HTTPException(409, 'Cette course a changé sur un autre appareil. Actualise puis réessaie.')


@app.post('/api/v1/trips/{ident}/assign')
def assign(ident: str, body: Assignment, user=Depends(dispatcher)):
    with tx() as db:
        t = get(db, 'trips', ident)
        version_check(t, body.version)
        if t['status'] not in {'pending', 'scheduled'}:
            raise HTTPException(409, 'Cette course est déjà attribuée ou terminée.')
        if t.get('scheduled_at') and stamp(t['scheduled_at']) > time.time() + 1800:
            raise HTTPException(409, 'Attribution possible à partir de 30 minutes avant le départ.')
        available = [d for d in rows(db, 'drivers') if compatible(d, t)]
        if body.driver_id:
            available = [d for d in available if d['id'] == body.driver_id]
        else:
            available = [d for d in available if fresh(d)]
            available.sort(key=lambda d: distance(d, t['pickup']))
        if not available:
            raise HTTPException(409, 'Aucun chauffeur compatible disponible' + ('.' if body.driver_id else ' avec une position de moins de 5 minutes.'))
        d = available[0]
        t.update(driver_id=d['id'], status='assigned', version=t['version'] + 1, updated_at=now())
        d['status'] = 'busy'
        put(db, 'trips', t)
        put(db, 'drivers', d)
        audit(db, user, 'trip.assigned', ident, d['id'])
        return t


class StatusChange(BaseModel):
    status: Literal['en_route', 'on_board', 'completed', 'cancelled']
    version: int = Field(ge=1)


@app.post('/api/v1/trips/{ident}/status')
def trip_status(ident: str, body: StatusChange, user=Depends(current_user)):
    with tx() as db:
        t = get(db, 'trips', ident)
        if user['role'] == 'driver' and t.get('driver_id') != user['driver_id']:
            raise HTTPException(403, 'Cette course ne t’est pas attribuée.')
        if user['role'] == 'driver' and body.status == 'cancelled':
            raise HTTPException(403, 'Contacte le dispatch pour annuler une course.')
        version_check(t, body.version)
        if body.status not in TRANSITIONS[t['status']]:
            raise HTTPException(409, 'Cette transition de course n’est pas possible.')
        t.update(status=body.status, version=t['version'] + 1, updated_at=now())
        if body.status in {'completed', 'cancelled'} and t.get('driver_id'):
            d = get(db, 'drivers', t['driver_id'])
            d['status'] = 'available'
            put(db, 'drivers', d)
        if body.status == 'completed':
            t['completed_at'] = now()
        put(db, 'trips', t)
        audit(db, user, 'trip.' + body.status, ident)
        return t


class Payment(BaseModel):
    amount_cents: int = Field(ge=0, le=1000000)
    method: Literal['cash', 'card', 'account']
    version: int = Field(ge=1)


@app.post('/api/v1/trips/{ident}/payment')
def payment(ident: str, body: Payment, user=Depends(current_user)):
    with tx() as db:
        t = get(db, 'trips', ident)
        if user['role'] == 'driver' and t.get('driver_id') != user['driver_id']:
            raise HTTPException(403, 'Accès refusé.')
        version_check(t, body.version)
        if t['status'] != 'completed' or t['payment_status'] == 'paid':
            raise HTTPException(409, 'Seule une course terminée et non encaissée peut être enregistrée.')
        if t.get('checkout_expires',0)>time.time():
            raise HTTPException(409, 'Un paiement Stripe est en cours. Attends son expiration ou sa confirmation.')
        t.update(payment_status='paid', payment_method=body.method, paid_cents=body.amount_cents,
                 paid_at=now(), version=t['version'] + 1, updated_at=now())
        put(db, 'trips', t)
        audit(db, user, 'payment.recorded', ident, str(body.amount_cents))
        return t


class SettingsInput(BaseModel):
    company: str = Field(min_length=2, max_length=100)
    base: float = Field(ge=0, le=10000)
    per_km: float = Field(ge=0, le=1000)
    per_minute: float = Field(ge=0, le=1000)
    minimum: float = Field(ge=0, le=10000)
    van_extra: float = Field(ge=0, le=10000)


@app.patch('/api/v1/settings')
def settings(body: SettingsInput, user=Depends(current_user)):
    if user['role'] != 'admin':
        raise HTTPException(403, 'Accès administrateur requis.')
    obj = {**body.model_dump(), 'currency': 'EUR'}
    with tx() as db:
        db.execute('UPDATE settings SET data=? WHERE id=1', (json.dumps(obj),))
        audit(db, user, 'settings.updated', 'settings')
    return obj


@app.get('/api/v1/audit')
def audit_log(user=Depends(dispatcher)):
    with closing(connection()) as db:
        return [dict(r) for r in db.execute('SELECT * FROM audit ORDER BY id DESC LIMIT 150')]


@app.get('/api/v1/export.csv', response_class=PlainTextResponse)
def export(user=Depends(dispatcher)):
    output = io.StringIO()
    writer = csv.writer(output, delimiter=';')
    writer.writerow(['Référence', 'Client', 'Départ', 'Arrivée', 'Statut', 'Estimation EUR', 'Encaissé EUR', 'Paiement', 'Date'])
    def safe(value):
        value = str(value or '')
        return "'" + value if value.startswith(('=', '+', '-', '@', '\t', '\r')) else value
    with closing(connection()) as db:
        for t in rows(db, 'trips'):
            writer.writerow([safe(x) for x in [t['id'], t['passenger'], t['pickup']['label'], t['destination']['label'],
                              t['status'], t['fare_cents'] / 100, t.get('paid_cents', 0) / 100,
                              t['payment_status'], t['created_at']]])
    return PlainTextResponse('\ufeff' + output.getvalue(), media_type='text/csv',
                             headers={'Content-Disposition': 'attachment; filename="taxiflow-courses.csv"'})


from .features import install
install(app)

app.mount('/', StaticFiles(directory=Path(__file__).parent.parent / 'web', html=True), name='web')
